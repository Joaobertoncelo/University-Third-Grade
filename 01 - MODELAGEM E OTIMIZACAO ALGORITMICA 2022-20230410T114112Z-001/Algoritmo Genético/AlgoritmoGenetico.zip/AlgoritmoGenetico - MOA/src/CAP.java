/**
        Andrei Roberto da Costa 107975
        Joao Gilberto 112684
        Felipe Piassa Antonucci Esperança 112647
 */

import java.util.Random ;

public class CAP {
    // Definindo parâmetros do algoritmo genético
    private int populationSize ;
    private int numGenerations ;
    private double mutationRate ;
    private double crossoverRate ;
    
    // Definindo as variáveis do problema de otimização
    private int numClasses ;
    private int numRooms ;
    private int numTimeslots ;
    private int[][] classes ;
    
    // Definindo a população inicial
    private int[][] population ;





    // Construtor da classe
    public CAP(int populationSize, int numGenerations, double mutationRate, double crossoverRate, int numClasses, int numRooms, int numTimeslots, int[][] classes) 
    {
        this.populationSize = populationSize ;
        this.numGenerations = numGenerations ;
        this.mutationRate = mutationRate ;
        this.crossoverRate = crossoverRate ;
        this.numClasses = numClasses ;
        this.numRooms = numRooms ;
        this.numTimeslots = numTimeslots ;
        this.classes = classes ;
         
    }





    // Método que inicializa a população aleatoriamente.
    public void initializePopulation() 
    {
        // Utiliza a classe Random para gerar números aleatórios.
        Random random = new Random() ;

        /*
            A matriz population armazena os indivíduos da população.

            --> Cada linha da matriz representa um indivíduo e cada coluna representa uma disciplina.
            -> O valor de populationSize é o tamanho da população.
            -> O valor de numClasses é o número de disciplinas.
            -> O valor de numRooms é o número de salas disponíveis.
            -> O valor de numTimeslots é o número de horários disponíveis para as aulas.
        */
        population = new int[populationSize][numClasses] ;
        
        for (int i = 0; i < populationSize; i++) 
        {
            for (int j = 0; j < numClasses; j++) 
            {
                // Gera um número aleatório para a sala e horário da disciplina j do indivíduo i.
                population[i][j] = random.nextInt(numRooms * numTimeslots) ;
            }
        }
    }





    // Avalia a aptidão de um indivíduo.
    private int evaluateFitness(int[] individual) 
    {
        // A variável fitness representa a aptidão do indivíduo e é inicializada com valor zero.
        int fitness = 0 ;

        // O método utiliza a matriz schedule para armazenar o horário das disciplinas do indivíduo.
        int[][] schedule = new int[numRooms][numTimeslots] ;
        
        for (int i = 0; i < numClasses; i++) 
        {
            // Obtém a sala e horário para a disciplina i do indivíduo.
            int room = individual[i] / numTimeslots ;
            int timeslot = individual[i] % numTimeslots ;

            // Verifica se a sala e horário já estão ocupados por outra disciplina
            if (schedule[room][timeslot] != 0) 
            {
                // Decrementa a aptidão do indivíduo caso haja conflito de horário.
                fitness-- ;
            }

            // Marca a disciplina na matriz schedule.
            schedule[room][timeslot] = classes[i][0] ;
        }

        // Retorna a aptidão do indivíduo.
        return fitness ;
    }





    /**

     Método que avalia a aptidão de todos os indivíduos da população.

     -> Utiliza a função evaluateFitness para calcular a aptidão de cada indivíduo da população.
     -> A matriz population armazena os indivíduos da população.
     -> Cada linha da matriz representa um indivíduo e cada coluna representa uma disciplina.
     -> O vetor fitnessValues armazena a aptidão de cada indivíduo da população.
     -> O valor de populationSize é o tamanho da população.
     -> O método retorna o vetor fitnessValues com as aptidões de todos os indivíduos da população.

     */
    private int[] evaluateFitness() 
    {
        int[] fitnessValues = new int[populationSize] ;
        
        for (int i = 0; i < populationSize; i++) 
        {
            // Calcula a aptidão do indivíduo i e armazena no vetor fitnessValues.
            fitnessValues[i] = evaluateFitness(population[i]) ;
        }

        // Retorna o vetor fitnessValues com as aptidões de todos os indivíduos da população.
        return fitnessValues;
    }





    /**

     Método que realiza a seleção de indivíduos para o crossover.

     -> A seleção é realizada aleatoriamente a partir da avaliação da aptidão de cada indivíduo da população.
     -> O vetor fitnessValues armazena a aptidão de cada indivíduo da população.
     -> A matriz population armazena os indivíduos da população.
     -> Cada linha da matriz representa um indivíduo e cada coluna representa uma disciplina.
     -> A matriz parents armazena os indivíduos selecionados para o crossover.
     -> A primeira linha da matriz representa o primeiro pai e a segunda linha representa o segundo pai.
     -> O valor de numClasses é o número de disciplinas e o valor de populationSize é o tamanho da população.
     -> O método retorna a matriz parents com os indivíduos selecionados para o crossover.

     */
    private int[][] selection(int[] fitnessValues) 
    {
        int[][] parents = new int[2][numClasses] ;
        Random random = new Random() ;
        int index1 = random.nextInt(populationSize) ;
        int index2 = random.nextInt(populationSize) ;

        // Seleciona o primeiro pai de forma aleatória.
        if (fitnessValues[index1] > fitnessValues[index2]) 
        {
            parents[0] = population[index1] ;
        } 
        else 
        {
            parents[0] = population[index2] ;
        }
        
        index1 = random.nextInt(populationSize) ;
        index2 = random.nextInt(populationSize) ;

        // Seleciona o segundo pai de forma aleatória.
        if (fitnessValues[index1] > fitnessValues[index2]) 
        {
            parents[1] = population[index1] ;
        } 
        else 
        {
            parents[1] = population[index2] ;
        }

        // Retorna a matriz parents com os indivíduos selecionados para o crossover.
        return parents ;
    }





    // Método que realiza o crossover entre dois indivíduos.
    private int[][] crossover(int[] parent1, int[] parent2) 
    {
        // Cria dois indivíduos filhos.
        int[][] offspring = new int[2][numClasses] ;

        // Instancia um objeto random para gerar valores aleatórios.
        Random random = new Random() ;

        // Verifica se o crossover deve ser realizado com base na taxa de crossover definida.
        if (random.nextDouble() < crossoverRate) 
        {
            // Seleciona um ponto de crossover aleatório.
            int crossoverPoint = random.nextInt(numClasses - 1) + 1 ;

            // Realiza o crossover até o ponto de corte.
            for (int i = 0; i < crossoverPoint; i++) 
            {
                offspring[0][i] = parent1[i] ;
                offspring[1][i] = parent2[i] ;
            }

            // Realiza o crossover a partir do ponto de corte até o final do indivíduo.
            for (int i = crossoverPoint; i < numClasses; i++) 
            {
                offspring[0][i] = parent2[i] ;
                offspring[1][i] = parent1[i] ;
            }
        }
        // Caso contrário, os filhos são iguais aos pais
        else 
        {
            offspring[0] = parent1 ;
            offspring[1] = parent2 ;
        }

        // Retorna os indivíduos filhos gerados pelo crossover.
        return offspring ;
    }





    /**

     Método que realiza a mutação de um indivíduo.
     @param individual : Indivíduo a ser mutado.

     */
    private void mutate(int[] individual) 
    {
        Random random = new Random() ;

        // Verifica se a taxa de mutação é atendida.
        if (random.nextDouble() < mutationRate) 
        {
            // Seleciona dois genes aleatórios.
            int gene1 = random.nextInt(numClasses) ;
            int gene2 = random.nextInt(numClasses) ;

            // Troca os valores dos genes selecionados.
            int temp = individual[gene1] ;
            individual[gene1] = individual[gene2] ;
            individual[gene2] = temp ;
        }
    }





    // Método que realiza a evolução da população.
    public int[] evolve() 
    {
        // Inicializa a população e avalia sua aptidão.
        initializePopulation() ;
        int[] fitnessValues = evaluateFitness();

        // Realiza o número de gerações especificado.
        for (int i = 0; i < numGenerations; i++)
        {
            int[][] newPopulation = new int[populationSize][numClasses] ;

            // Realiza o crossover e a mutação para cada par de pais.
            for (int j = 0; j < populationSize; j += 2)
            {
                int[][] parents = selection(fitnessValues) ;
                int[][] offspring = crossover(parents[0], parents[1]) ;
                mutate(offspring[0]) ;
                mutate(offspring[1]) ;
                newPopulation[j] = offspring[0] ;
                newPopulation[j + 1] = offspring[1] ;
            }

            // Substitui a população antiga pela nova e avalia a aptidão.
            population = newPopulation ;
            fitnessValues = evaluateFitness() ;

            // Encontra o melhor valor de aptidão na população atual.
            int bestFitness = fitnessValues[0] ;
            for (int j = 1; j < populationSize; j++)
            {
                if (fitnessValues[j] > bestFitness)
                {
                    bestFitness = fitnessValues[j] ;
                }
            }
        }

        // Retorna os valores de aptidão da última geração.
        return fitnessValues ;
    }





    // Método que retorna o melhor indivíduo da população.
    public int[] getBestIndividual() 
    {
        int bestIndex = 0 ;

        // Avalia a aptidão de todos os indivíduos da população.
        int[] fitnessValues = evaluateFitness() ;

        // Armazena a aptidão do primeiro indivíduo como melhor aptidão inicial.
        int bestFitness = fitnessValues[0] ;

        // Loop para encontrar o melhor indivíduo da população.
        for (int i = 1; i < populationSize; i++) 
        {
            // Se a aptidão do indivíduo atual é maior que a melhor aptidão anterior.
            if (fitnessValues[i] > bestFitness) 
            {
                // Atualiza a melhor aptidão.
                bestFitness = fitnessValues[i] ;

                // Armazena o índice do melhor indivíduo.
                bestIndex = i ;
            }
        }

        // Retorna o melhor indivíduo.
        return population[bestIndex] ;
    }
}
