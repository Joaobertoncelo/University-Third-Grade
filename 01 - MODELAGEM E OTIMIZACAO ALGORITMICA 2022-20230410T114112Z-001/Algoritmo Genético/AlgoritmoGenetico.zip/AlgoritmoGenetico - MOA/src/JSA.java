/**
        Andrei Roberto da Costa 107975
        Joao Gilberto 112684
        Felipe Piassa Antonucci Esperança 112647
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

public class JSA {

    private final int populationSize ;
    private final int numMachines ;
    private final int numTasks ;
    private final List<Integer> taskTimes ;
    private List<List<Integer>> population ;
    private final Random random = new Random() ;

    public JSA(int populationSize, int numMachines, List<Integer> taskTimes) 
    {
        this.populationSize = populationSize;
        this.numMachines = numMachines;
        this.numTasks = taskTimes.size();
        this.taskTimes = taskTimes;
        initializePopulation();
    }
    
    // Método responsável por criar e inicializar uma população de soluções para um algoritmo genético.
    private void initializePopulation() 
    {
        // Cria um novo objeto ArrayList com o tamanho especificado pela variável "populationSize".
        population = new ArrayList<>(populationSize);
        
        // Loop que itera "populationSize" vezes para criar uma nova solução para cada iteração.
        for (int i = 0; i < populationSize; i++) 
        {
            // Cria um novo objeto List<Integer> chamado "solution" com o tamanho especificado pela variável "numTasks".
            List<Integer> solution = new ArrayList<>(numTasks) ;
            
            // Loop interno que itera "numTasks" vezes para preencher a solução com valores aleatórios.
            for (int j = 0; j < numTasks; j++) 
            {
                // Adiciona um valor aleatório gerado pela variável "random" ao objeto "solution".
                solution.add(random.nextInt(numMachines)) ;
            }
            
            // Adiciona a solução criada à população.
            population.add(solution) ;
        }
    }
    
    
    // Método que calcula a aptidão de uma solução passada como parâmetro.
    private int fitness(List<Integer> solution) 
    {
        // Cria um novo array "machineTimes" com o tamanho especificado pela variável "numMachines".
        int[] machineTimes = new int[numMachines];
        
        // Loop que itera "numTasks" vezes para calcular os tempos de processamento de cada tarefa em cada máquina.
        for (int i = 0; i < numTasks; i++) 
        {
            // Obtém a máquina alocada para a tarefa "i" na solução "solution".
            int machine = solution.get(i) ;
            
            // Adiciona o tempo de processamento da tarefa "i" ao tempo total de processamento da máquina "machine".
            machineTimes[machine] += taskTimes.get(i) ;
        }
        
        // Retorna o tempo de processamento da máquina com o maior tempo de processamento.
        return IntStream.of(machineTimes).max().getAsInt();
    }
    
    
    // Realiza a seleção de dois indivíduos aleatórios da população e retorna aquele com menor valor de fitness.
    private List<Integer> selection() 
    {   
        // Seleciona aleatoriamente dois pais da população.
        List<Integer> parent1 = population.get(random.nextInt(populationSize)) ;
        List<Integer> parent2 = population.get(random.nextInt(populationSize)) ;
        
        // Retorna o pai com menor valor de fitness.
        return fitness(parent1) < fitness(parent2) ? parent1 : parent2 ;
    }
    
    
    // Realiza o crossover de dois indivíduos (pais), gerando um novo indivíduo (filho).
    // @param 'parent1': Lista de tarefas do pai 1.
    // @param 'parent2': Lista de tarefas do pai 2.
    private List<Integer> crossover(List<Integer> parent1, List<Integer> parent2) 
    {
        // Seleciona aleatoriamente o ponto de crossover.
        int crossoverPoint = random.nextInt(numTasks) ;
        
        // Cria uma nova lista para armazenar as tarefas do filho.
        List<Integer> child = new ArrayList<>(numTasks) ;
        
        // Adiciona as primeiras tarefas do pai 1 na lista do filho, até o ponto de crossover.
        child.addAll(parent1.subList(0, crossoverPoint)) ;
        
        // Adiciona as tarefas restantes do pai 2 na lista do filho, a partir do ponto de crossover.
        child.addAll(parent2.subList(crossoverPoint, numTasks)) ;
        
        // Retorna a lista de tarefas do filho gerado.
        return child ;
    }
    
    
    // Realiza a mutação em uma solução do problema JSA, alterando aleatoriamente um dos genes da solução.
    private void mutation(List<Integer> solution) 
    {
        // A posição do gene a ser mutado é escolhida aleatoriamente entre 0 e o número total de tarefas.
        int mutationPoint = random.nextInt(numTasks) ;
        
        // O valor do gene é alterado para um valor aleatório entre 0 e o número total de máquinas disponíveis.
        solution.set(mutationPoint, random.nextInt(numMachines)) ;
    }
    
    
    // Resolve o problema de escalonamento de tarefas em máquinas utilizando o algoritmo genético JSA.
    // @param 'maxIterations' : Número máximo de iterações que o algoritmo deve executar.
    public List<Integer> solve(int maxIterations) 
    {
        for (int i = 0; i < maxIterations; i++) 
        {
            // Cria uma nova população de soluções.
            List<List<Integer>> newPopulation = new ArrayList<>(populationSize) ;
            
            // Loop para gerar uma nova população.
            for (int j = 0; j < populationSize; j++) 
            {
                // Seleciona os pais para o crossover.
                List<Integer> parent1 = selection();
                List<Integer> parent2 = selection();
                
                // Faz o crossover dos pais e gera um filho.
                List<Integer> child = crossover(parent1, parent2);
                
                // Faz a mutação no filho gerado.
                mutation(child) ;
                
                // Adiciona o filho na nova população.
                newPopulation.add(child) ;
            }
            
            // A nova população substitui a antiga população.
            population = newPopulation ;
        }
        
        // Retorna a melhor solução encontrada na população.
        return Collections.min(population, Comparator.comparingInt(this::fitness)) ;
    }
}
