/**
        Andrei Roberto da Costa 107975
        Joao Gilberto 112684
        Felipe Piassa Antonucci Esperança 112647
*/

import java.util.Arrays ;
import java.util.List ;

public class Main {

    public static void main(String[] args) 
    {
        /*Job Schedulling Problem*/
        
        /* ------------------------ Configuração 1 ------------------------*/
        
        int populationSize_1 = 200 ; // População Inicial -> 200
        int numMachines_1 = 5 ; // Máquinas Disponíveis -> 5
        List<Integer> taskTimes_1 = Arrays.asList(8, 10, 5, 7, 9, 4, 6, 3, 5, 7, 6, 9, 8, 10, 7, 6, 8, 5, 3, 4) ;
        
        /* ------------------------ Configuração 2 ------------------------*/
        
        int populationSize_2 = 100 ; // População Inicial -> 100
        int numMachines_2 = 4 ; // Máquinas Disponíveis -> 4
        List<Integer> taskTimes_2 = Arrays.asList(7, 4, 9, 6, 8, 5, 10, 3, 7, 6, 4, 9, 8, 5, 6, 7, 4) ;
        
        
        // Criação de uma instância da classe JSA, passando as variáveis como argumento para o construtor.
        JSA jsa_1 = new JSA(populationSize_1, numMachines_1, taskTimes_1) ; // Configuração 1.
        JSA jsa_2 = new JSA(populationSize_2, numMachines_2, taskTimes_2) ; // Configuração 2.
        
        // Execução do algoritmo genético e armazenamento da melhor solução encontrada em uma lista de inteiros.
        List<Integer> bestSolutionJSA_1 = jsa_1.solve(1000) ; // Configuração 1 em 1000 Iterações.
        List<Integer> bestSolutionJSA_2 = jsa_2.solve(1000) ; // Configuração 2 em 1000 Iterações.
        
        // Exibição da melhor solução encontrada.
        System.out.println("*********** Job Schedulling Problem ***********\n");
        System.out.println("Melhor solução encontrada(Configuração 1): " + bestSolutionJSA_1) ; // Configuração 1.
        System.out.println("Melhor solução encontrada(Configuração 2): " + bestSolutionJSA_2) ; // Configuração 2.
        
        /*---------------------------------------------------------------------------------------------------------------------------------------------*/


        /* Classroom Assignment Problem */

        /* ------------------------ Configuração 1 ------------------------*/

        int populationSizeCAP_1 = 100 ;
        int numGenerationsCAP_1 = 500 ;
        double mutationRateCAP_1 = 0.01 ;
        double crossoverRateCAP_1 = 0.8 ;
        int numClassesCAP_1 = 10 ;
        int numRoomsCAP_1 = 3 ;
        int numTimeslotsCAP_1 = 5 ;
        int[][] classesCAP_1 = {
                {1, 2, 3, 4},
                {2, 3, 4, 1},
                {3, 4, 1, 2},
                {4, 1, 2, 3},
                {1, 2, 3, 4},
                {2, 3, 4, 1},
                {3, 4, 1, 2},
                {4, 1, 2, 3},
                {1, 2, 3, 4},
                {2, 3, 4, 1}
        } ;

        /* ------------------------ Configuração 2 ------------------------*/

        int populationSizeCAP_2 = 150 ;
        int numGenerationsCAP_2 = 700 ;
        double mutationRateCAP_2 = 0.01 ;
        double crossoverRateCAP_2 = 0.8 ;
        int numClassesCAP_2 = 8 ;
        int numRoomsCAP_2 = 4 ;
        int numTimeslotsCAP_2 = 5 ;
        int[][] classesCAP_2 = {
                {1, 2, 3, 4},
                {2, 3, 4, 1},
                {3, 4, 1, 2},
                {4, 1, 2, 3},
                {1, 2, 3, 4},
                {2, 3, 4, 1},
                {3, 4, 1, 2},
                {4, 1, 2, 3},
                {1, 2, 3, 4},
                {2, 3, 4, 1}
        } ;

        // Criando uma instância do algoritmo genético
        CAP cap_1 = new CAP(populationSizeCAP_1, numGenerationsCAP_1, mutationRateCAP_1, crossoverRateCAP_1, numClassesCAP_1, numRoomsCAP_1, numTimeslotsCAP_1, classesCAP_1) ;
        CAP cap_2 = new CAP(populationSizeCAP_2, numGenerationsCAP_2, mutationRateCAP_2, crossoverRateCAP_2, numClassesCAP_2, numRoomsCAP_2, numTimeslotsCAP_2, classesCAP_2) ;

        // Inicializando a população aleatoriamente
        cap_1.initializePopulation() ;
        cap_2.initializePopulation() ;

        // Realizando a evolução da população por um número de gerações
        for (int i = 0; i < numGenerationsCAP_1; i++)
        {
            cap_1.evolve() ;
        }

        for (int i = 0; i < numGenerationsCAP_2; i++)
        {
            cap_2.evolve() ;
        }


        // Obtendo o melhor indivíduo da população final
        int[] bestIndividualCAP_1 = cap_1.getBestIndividual() ;
        int[] bestIndividualCAP_2 = cap_2.getBestIndividual() ;

        // Imprimindo o resultado
        System.out.println("\n*********** Classroom Assignment Problem ***********\n");
        System.out.println("Melhor Solução encontrada(Configuração 1): " + Arrays.toString(bestIndividualCAP_1)) ;
        System.out.println("Melhor Solução encontrada(Configuração 2): " + Arrays.toString(bestIndividualCAP_2)) ;

        /*---------------------------------------------------------------------------------------------------------------------------------------------*/
    }
}
