# -*- coding: utf-8 -*-
"""
### Implementação do algoritmo genético e resolução do problema do caixeiro viajante


*   Ra: 116086 - Nathalia Mesquita Carnevalli
*   Ra: 112680 - Rodrigo Vieira de Vasconcelos
*   Ra: 108176 - Arthur Gustavo Toyotani Campanha
"""

#Importando as bibliotecas necessárias 
import math as m
import random as r
import matplotlib.pyplot as plt

#Inicialização do problema do caixeiro viajante as cidades e as coordenadas (x, y) delas
cities = {
    'A': (0, 0),
    'B': (1, 5),
    'C': (2, 3),
    'D': (5, 1),
    'E': (6, 5),
    'F': (7, 3)
}

# Função que cria um indivíduo, ou seja, uma rota aleatória que o caixeiro viajante passou
def create_individual(cities):
    chromosome = list(cities.keys())
    r.shuffle(chromosome)
    return chromosome

# Função que cria a população, ou seja, várias rotas que o caixeiro viajante passou
def generate_population(population_size, cities):
   return [create_individual(cities) for _ in range(population_size)]

# Função que calcula a distância entre duas cidades
def calculate_distance(city1, city2):
   x1, y1 = cities[city1]
   x2, y2 = cities[city2]
   return m.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

# Função que calcula o custo do problema (soma as distâncias entre todas as cidades) 
def calculate_total_distance(cities_list):
   cost = 0 
   for i in range(len(cities_list) - 1):
     cost += calculate_distance(cities_list[i], cities_list[i+1])
   return cost + calculate_distance(cities_list[-1], cities_list[0])

# Função que calcula o fitness
def calculate_fitness(individual, cities):
    total_distance = 0
    total_distance = calculate_total_distance(individual)
    return 1 / total_distance

# Função que ordena os indivíduos mais aptos
def fitness_score(population):
    fitness_scores = []
    for individual in population:
        fitness = calculate_fitness(individual, cities)
        fitness_scores.append((individual, fitness))
    fitness_scores = sorted(fitness_scores, key=lambda x: x[1], reverse=True)
    return fitness_scores

# Função que seleciona os pais
def selection_parents(fitness_scores):
    parents = []
    sum_fitness = 0
    for f in fitness_scores:
      sum_fitness += f[1]
    probabilities = [f[1] / sum_fitness for f in fitness_scores]
    for i in range(2):
         parents.append(r.choices(fitness_scores, probabilities)[0][0])
    return parents

# Função que faz o cruzamento
def crossover(parents):
    child = [-1] * len(parents[0])
    geneA = int(r.random() * len(parents[0]))
    geneB = int(r.random() * len(parents[0]))
    startGene = min(geneA, geneB)
    endGene = max(geneA, geneB)
    for i in range(startGene, endGene):
        child[i] = parents[0][i]

    for i in range(len(parents[1])):
        if parents[1][i] not in child:
            for j in range(len(child)):
                if child[j] == -1:
                    child[j] = parents[1][i]
                    break
    return child

# Função que faz a mutação do filho
def mutation(individual, mutation_rate):
    for i in range(len(individual)):
        if r.random() < mutation_rate:
            j = int(r.random() * len(individual))
            individual[i], individual[j] = individual[j], individual[i]
    return individual

# Função que cria uma nova geração
def next_generation(mutation_rate, population):
    generation = []
    visited_routes = []
    fitness_scores = fitness_score(population)
    for i in range(len(population)):
        parents = selection_parents(fitness_scores)
        child = crossover(parents)
        new_individual = mutation(child, mutation_rate)
        while new_individual in visited_routes:
          new_individual = mutation(child, mutation_rate)
        visited_routes.append(new_individual)
        generation.append(new_individual)
    return generation

# Algoritmo Genético
def genetic_algorithm(num_generation, mutation_rate, population_size): 
  bests = []
  population = generate_population(population_size, cities)
  generation = population
  for i in range(num_generation):
     generation = next_generation(mutation_rate, generation)
     best_individual = fitness_score(generation)[0][0]
     best_fitness = calculate_fitness(best_individual, cities)
     print("Generation:", i + 1, "\tBest individual:", best_individual, "\tBest fitness:", best_fitness)
     bests.append(best_fitness)
  generate_graph([i+1 for i in range(num_generation)], bests)

def generate_graph(bests, num_generation):
  plt.plot(bests, num_generation)
  plt.show()

#Configuração 1:
# Número de gerações = 20
# Probabilidade de mutação = 0.1
# Tamanho da população = 10
genetic_algorithm(20, 0.05, 10)

genetic_algorithm(20, 0.05, 10)

genetic_algorithm(20, 0.05, 10)

#Configuração 2:
# Número de gerações = 20
# Probabilidade de mutação = 0.01 
# Tamanho da população = 10
genetic_algorithm(20, 0.01, 10)

genetic_algorithm(20, 0.01, 10)

genetic_algorithm(20, 0.01, 10)

