

#Importando as bibliotecas necessárias 
import math as m
import random as r
import networkx as nx
import matplotlib.pyplot as plt

#Inicialização da coloração de grafos
graph = nx.gnp_random_graph(10, 0.33)

# Função para gerar um indivíduo aleatório (Nó recebe cor aleatória pré-definida)
def generate_individual(graph, num_colors):
    individual = {}
    for node in graph.nodes():
        individual[node] = r.randint(1, num_colors)
    return individual

# Função para gerar uma população inicial aleatória (colorações do grafo)
def generate_population(graph, num_colors, population_size):
    population = [generate_individual(graph, num_colors)
        for i in range(population_size)]
    return population

# Função para avaliar a qualidade de um indivíduo
def calculate_fitness(individual, graph):
    num_adjacent_pairs = 0
    num_different_colors = 0
    for edge in graph.edges():
        num_adjacent_pairs += 1
        if individual[edge[0]] != individual[edge[1]]:
            num_different_colors += 1
    if num_adjacent_pairs == 0:
        fitness = 1
    else:
        fitness = num_different_colors / num_adjacent_pairs
    return fitness

# Função que ordena os indivíduos mais aptos
def fitness_score(population):
    fitness_scores = []
    for individual in population:
        fitness = calculate_fitness(individual, graph)
        fitness_scores.append((individual, fitness))
    fitness_scores = sorted(fitness_scores, key=lambda x: x[1], reverse=True)
    return fitness_scores

# Função que seleciona os pais
def selection_parents(fitness_scores):
    parents = []
    sum_fitness = 0
    for f in fitness_scores:
      sum_fitness += f[1]
    probabilities = [f[1] / sum_fitness for f in fitness_scores]
    for i in range(2):
         parents.append(r.choices(fitness_scores, probabilities)[0][0])
    return parents

# Função que faz o cruzamento
def crossover(parents):
    child = {}
    for vertex in parents[0]:
        if r.random() < 0.5:
            child[vertex] = parents[0][vertex]
        else:
            child[vertex] = parents[1][vertex]
    return child

#Função que faz a mutação do filho
def mutation(individual, mutation_rate):
    for i in range(len(individual)):
        if r.random() < mutation_rate:
            j = int(r.random() * len(individual))
            individual[i], individual[j] = individual[j], individual[i]
    return individual

# Função que cria uma nova geração
def next_generation(population, num_colors, mutation_rate, population_size):
    generation = []
    fitness_scores = fitness_score(population)
    elite_size = round(population_size * 0.05)

    if elite_size < 1:
        elite_size = 1
    for i in range(elite_size):
        generation.append(fitness_scores[i][0])
    for i in range(len(population)):
        parents = selection_parents(fitness_scores)
        child = crossover(parents)
        new_individual = mutation(child, mutation_rate)
        generation.append(new_individual)
    return generation

# Algoritmo Genético
def genetic_algorithm(graph, num_colors, num_generation, mutation_rate, population_size):
    population = generate_population(graph, num_colors, population_size)
    bests = []
    for i in range(num_generation):
        generation = next_generation(
            population, num_colors, mutation_rate, population_size)
        best_individual = fitness_score(generation)[0][0]
        population = generation
        best_fitness = calculate_fitness(best_individual, graph)
        print("Generation:", i + 1, "\tBest individual:", best_individual, "\tBest fitness:", best_fitness)
        bests.append(best_fitness)
    generate_graph([i+1 for i in range(num_generation)], bests)

def generate_graph(bests, num_generation):
  plt.plot(bests, num_generation)
  plt.show()

#Configuração 1:
# Número de cores = 4
# Número de gerações = 20
# Probabilidade de mutação = 0.05
# Tamanho da população = 10
genetic_algorithm(graph, 4, 20, 0.05, 30)

genetic_algorithm(graph, 4, 20, 0.05, 30)

genetic_algorithm(graph, 4, 20, 0.05, 30)

#Configuração 2:

# Número de cores = 4
# Número de gerações = 20
# Probabilidade de mutação = 0.1 
# Tamanho da população = 40
genetic_algorithm(graph, 4, 20, 0.1, 30)

genetic_algorithm(graph, 4, 20, 0.1, 30)

genetic_algorithm(graph, 4, 20, 0.1, 30)