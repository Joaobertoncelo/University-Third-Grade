import random
from typing import List


class Schedule():
    def __init__(
            self, tasks: List, adj: List,
            processors: int, schedule=None, height=None
            ):

        """
        Inicializa uma possível solução para o problema de
        escalonamento de tarefas.

        - tasks: Lista de tamanho n de tempos de execução de cada tarefa
        - adj: Matriz de ordem nxn de adjacência do grafo de precedência
        - processors: Número de processadores (m)
        - schedule: Escalonamento inicial de tarefas (opcional, matriz mxn)
        """

        self.processors = processors
        self.tasks = tasks
        self.adj = adj

        if not height:
            # Calcula a altura de cada tarefa
            # (Busca em profundidade)
            self.height = []
            for task in range(0, len(tasks)):
                dep = dfs(adj, task)
                self.height.append(len(dep))
        else:
            self.height = height

        if not schedule:
            self.schedule = [[] for i in range(0, self.processors)]

            height_dict = {h:
                           [x for x in range(0, len(tasks))
                            if self.height[x] == h]
                           for h in range(1, max(self.height)+1)}

            for h in range(1, max(self.height) + 1):
                for i in range(0, self.processors-1):
                    num = random.randint(0, len(height_dict[h]))

                    for j in range(0, num):
                        t = height_dict[h].pop()
                        self.schedule[i].insert(0, t)

            for h in range(1, max(self.height) + 1):
                for t in height_dict[h]:
                    self.schedule[-1].insert(0, t)

        else:
            self.schedule = schedule

        # tempo máximo de execução em série
        self.cmax = sum(self.tasks)

    def tempo_total(self):
        # calcula o tempo total de cada processador
        s = [0, 0, 0]

        for i in range(0, self.processors):
            for j in range(0, len(self.schedule[i])):
                s[i] += self.tasks[self.schedule[i][j]]

        return s

    def avaliar(self):
        """
        Calcula o valor da função de aptidão para o escalonamento
        """

        # modifica a função para maximizar o menor tempo de execução
        return self.cmax - max(self.tempo_total())

    def mutar(self):
        """
        Realiza uma mutação aleatória no índividuo, trocando de lugar
        uma tarefa aleatória e a primeira tarefa com a mesma altura
        """

        # escolhe uma tarefa
        t1 = random.randint(0, len(self.tasks)-1)

        # encontra uma tarefa com a mesma altura
        t2 = None
        for i in range(0, len(self.tasks)):
            if t1 != i and self.height[i] == self.height[t1]:
                t2 = i

        # encontra a posição das tarefas no escalonamento
        p1, pos1 = None, None
        p2, pos2 = None, None
        for i in range(0, self.processors):
            for j in range(0, len(self.schedule[i])):
                if self.schedule[i][j] == t1:
                    p1, pos2 = i, j
                elif self.schedule[i][j] == t2:
                    p2, pos2 = i, j

        # troca as tarefas de lugar
        if p1 and pos1 and p2 and pos2:
            self.schedule[p1][pos1] = t2
            self.schedule[p2][pos2] = t1

    def reproduzir(self, other):
        """
        Retorna um indivíduo formado tomando partes
        aleatórias de self e other.
        - other: Schedule
        """

        schedule = []
        c = random.randint(1, max(self.height))  # altura do ponto de crossover

        # pontos de crossover para cada indiíduo e processador
        p = [[0 for j in range(0, self.processors)] for i in range(0, 2)]

        for i in range(0, self.processors):
            # encontra pontos de crossover para cada processador de self
            for j in range(0, len(self.schedule[i]) - 1):
                if self.height[self.schedule[i][j]] >= c:
                    if self.height[self.schedule[i][j + 1]] > c:
                        p[0][i] = j

            # encontra pontos de crossover para cada processador de other
            for j in range(0, len(other.schedule[i]) - 1):
                if self.height[other.schedule[i][j]] >= c:
                    if self.height[other.schedule[i][j + 1]] > c:
                        p[1][i] = j

            # junta as duas partes de cada processador
            schedule.append(
                    self.schedule[i][:p[0][i]]
                    + other.schedule[i][p[1][i]:]
                    )

        # cria um novo estado
        child = Schedule(
                self.tasks, self.adj, self.processors,
                schedule=schedule, height=self.height
                )

        return child

    def __repr__(self):
        """
        Retorna uma representação da estrutura em string
        """

        out = ""

        # Representação do escalonamento
        for i in range(0, self.processors):
            out += "%02d: " % (i) + str(self.schedule[i])
            out += " -> %02d \n" % (self.tempo_total()[i])
        out += "Total: %02d" % (max(self.tempo_total()))

        return out


def dfs(adj, start, visited=None):
    """
    Retorna o maior caminho partindo de um vértice do grafo,
    através da busca em profundidade.
    """
    if not visited:
        visited = [False for i in range(0, len(adj))]

    visited[start] = True
    path = [[start]]

    for i in range(0, len(adj)):
        if adj[start][i] and not visited[i]:
            p = [start] + dfs(adj, i, visited)
            path.append(p)

    return max(path, key=len)


def busca(m, tasks: List, adj: List, iter_max=300, p=25, n=300, show=False):
    """
    - m: número de processadores
    - tasks: lista de tempo de execução das tarefas
    - adj: matriz de adjacência do grafo de dependências
    - iter_max: número máximo de iterações
    - p: número de indiíduos a se reproduzirem
    - n: tamanho da população
    - show: printar melhor indivíduo de cada geração
    """

    # população inicial
    pop = [Schedule(tasks, adj, m) for i in range(0, n)]
    best = pop[0]

    for i in range(0, iter_max):
        # ordena a população pela função de aptidão
        pop.sort(key=lambda x: x.avaliar())

        if pop[0].avaliar() > best.avaliar():
            best = pop[0]

        if show:
            print(best)
            print("Fit: " + str(best.avaliar()) + "\n")

        parents = []

        # seleção por torneio
        for j in range(0, p):
            p1, p2 = random.sample(pop, 2)
            parents.append(max(p1, p2, key=lambda x: x.avaliar()))

        new_pop = []

        # gerando novos indivíduos
        for j in range(0, p//2):
            for k in range(p//2, p):
                x = pop[j].reproduzir(pop[k])

                if random.random() < 0.10:
                    x.mutar()

                new_pop.append(x)

        # substituindo os piores indivíduos pela nova geração
        for j in range(0, p):
            pop[- j] = new_pop[j]

    return best


tasks1 = [30, 29, 17, 48, 34]
adj1 = [[False, True, False, True, False],
        [False, False, True, True, False],
        [False, False, False, False, False],
        [False, False, False, False, False],
        [False, False, False, False, False]]

res = busca(2, tasks1, adj1, show=False)
print(res)
print()

tasks2 = [6, 15, 27, 2, 11]
adj2 = [[False, False, False, True, True],
        [False, False, False, False, False],
        [False, False, False, False, False],
        [False, False, False, False, False],
        [False, False, False, False, False]]

res = busca(2, tasks2, adj2, show=False)
print(res)
