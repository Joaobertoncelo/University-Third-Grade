import graphf
from math import floor
from random import shuffle, randint, choice

def generate_individual(graph:list) -> list:
    graph_degree = graphf.get_largest_degree(graph)
    max_colors = graph_degree + 1
    individual = []
    
    for i in range(len(graph)):
        individual.append(randint(1, max_colors))
    
    return individual

def generate_population(graph: list, population_size: int) -> list:
    population = []
    
    for i in range(population_size):
        individual = generate_individual(graph)
        population.append(individual)
        
    return population

def fitness(graph: list, individual: list) -> int:   
    num_vertices = len(graph)
    num_colors = len(set(individual))
    num_conflicts = 0
    
    for i in range(num_vertices - 1):
        j = i + 1
        vertex_conflicts = 0
        
        while(j < num_vertices and vertex_conflicts < 1):
            if(graph[i][j] == 1):
                if(individual[i] == individual[j]): 
                    vertex_conflicts += 1
            j += 1
            
        num_conflicts += vertex_conflicts
            
    return num_vertices - num_conflicts - floor(num_colors * 0.5)

def crossover(indiv1: list, indiv2: list):
    crossover_point = randint(0, len(indiv1))
    
    children1 = indiv1[:crossover_point] + indiv2[crossover_point:]
    children2 = indiv2[:crossover_point] + indiv1[crossover_point:]
    
    return children1, children2

def evaluate_individues(graph: list, indiv1: list, indiv2: list) -> list:
    if(fitness(graph, indiv1) > fitness(graph, indiv2)): 
        return indiv1
    
    return indiv2

def tournament_selection(graph: list, population: list) -> list:
    selected_population = []
        
    for i in range(floor(len(population)/2)):
        selected_individual = evaluate_individues(
            graph,
            population[2*i],
            population[2*i + 1]
        )
        
        selected_population.append(selected_individual)
        
    return selected_population

def elitism_selection(graph: list, population: list) -> list:
    sorted_population = population
    fitness_values = []
    for vertex in sorted_population:fitness_values.append(fitness(graph, vertex))
    
    zipped_lists = zip(fitness_values, sorted_population)
    sorted_pairs = sorted(zipped_lists, reverse=True)
    
    tuples = zip(*sorted_pairs)
    fitness_values, sorted_population = [list(tuple) for tuple in tuples]
    
    bests = sorted_population[:floor(len(population)/2)]
    new_population = bests.copy()
    
    return new_population

def mutation(individual: list) -> list:
    rand_vertex = randint(0, len(individual) - 1)
    if(individual[rand_vertex] == 1): individual[rand_vertex] += 1
    else: individual[rand_vertex] -= 1
    
    return individual

def generate_childrens(selected_population: list) -> list:
    selected_individues = selected_population.copy()
    childrens = []
    
    while(len(selected_individues) > 1):
        indiv1 = selected_individues.pop(randint(0, len(selected_individues) - 1))
        indiv2 = selected_individues.pop(randint(0, len(selected_individues) - 1))
        
        children1, children2 = crossover(indiv1, indiv2)
        childrens.extend([children1, children2])
        
    return childrens
        
def best_in_population(graph: list, population: list) -> list:
    best = fitness(graph, population[0])
    index = 0
    
    for i in range(1, len(population)):
        fitness_value = fitness(graph, population[i])
        if(best < fitness_value): 
            best = fitness_value
            index = i 
            
    return population[index]

def genetic_algorithm(num_vertices: int, max_generations: int):
    # gera o grafo e geracao 0
    graph = graphf.init_random_graph(num_vertices)
    population = generate_population(graph, 200)
    current_generation = 0
    
    while(current_generation < max_generations):
        selected_individues = tournament_selection(graph, population)
        childrens = generate_childrens(selected_individues)
        
        # parte da mutacao
        for i in range(len(childrens)):
            percentage = randint(1, 100)
            if (percentage > 80):
                childrens[i] = mutation(childrens[i])
                
        population.extend(childrens)
    
        new_population = elitism_selection(graph, population)
        
        population = new_population
        
        current_generation += 1
        
    return graph, best_in_population(graph, population)
        
    
graph, best = genetic_algorithm(4, 10)
print("graph: ", graph)
print("optimal solution: ", best)

graph, best = genetic_algorithm(8, 12)
print("graph: ", graph)
print("optimal solution: ", best)