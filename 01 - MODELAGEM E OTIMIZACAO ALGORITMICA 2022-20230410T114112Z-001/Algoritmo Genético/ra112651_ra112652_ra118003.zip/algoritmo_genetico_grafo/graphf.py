# A estrutura grafo é definida por uma matriz (n x n),
# onde cada linha representa um vértice e cada coluna
# representa a ligacão do vértice da linha com os outros vertice.

from random import randint

def init_empty_graph(num_vertices: int) -> list:
    graph = []
    for i in range(num_vertices):       # inicializa as listas 
        adj_list = []                   # de vertices adjacentes
        for j in range(num_vertices):   
            adj_list.append(0)
            
        graph.append(adj_list)
        
    return graph

def init_random_graph(num_vertices: int) -> list:
    graph = init_empty_graph(num_vertices)
    link = 0
    for i in range(num_vertices):
        for j in range(num_vertices):
            if (i != j and graph[i][j] != 1): 
                link = randint(0, 1)
                if (link == 1):                # grafo
                    graph[i][j] = link         # não orientado
                    graph[j][i] = link
                
    return graph

# grau corresponde ao numero de vértices, o qual vértice atual esta ligado.
def get_largest_degree(graph: list) -> int:
    largest_degree = 0

    for vertex in graph:
        vertex_degree = sum(vertex)
        if(vertex_degree > largest_degree): largest_degree = vertex_degree
        
    return largest_degree