import numpy as np
import matplotlib.pyplot as plt
import time

from ant_colony import AntColony

distances = np.array([[np.inf, 2, 3, 2, 3],
                      [2, np.inf, 3, 4, 1],
                      [3, 3, np.inf, 2, 4],
                      [2, 4, 2, np.inf, 5],
                      [3, 3, 4, 5, np.inf]])

ant_colony = AntColony(distances, 5, 1, 20, 0.95, alpha=1, beta=1)
start = time.time() 
shortest_path, shortest_path_per_iter = ant_colony.run()
end = time.time()
print ("menor_caminho: {}".format(shortest_path))
print ("tempo_execucao: {} s".format(end - start))

graph_data = []
for path in shortest_path_per_iter:
    graph_data.append(path[1])

plt.plot(graph_data)
plt.title("Acompanhamento dos Valores")
plt.show()

