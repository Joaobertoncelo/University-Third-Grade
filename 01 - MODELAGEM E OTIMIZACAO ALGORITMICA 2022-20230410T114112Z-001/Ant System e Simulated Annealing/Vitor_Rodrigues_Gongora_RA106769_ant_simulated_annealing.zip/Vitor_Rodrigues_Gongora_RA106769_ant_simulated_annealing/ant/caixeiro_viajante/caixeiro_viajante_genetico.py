import array
import random
import time
import numpy

from deap import algorithms
from deap import base
from deap import creator
from deap import tools

import matplotlib.pyplot as plt

#Instancia de problema 1
problema1 = [
    #Nó 1
    [0, 2, 3, 2, 3],
    #Nó 2
    [2, 0, 3, 4, 1],
    #Nó 3
    [3, 3, 0, 2, 4],
    #Nó 4
    [2, 4, 2, 0, 5],
    #Nó 5
    [3, 3, 4, 5, 0]
]

distance_map = problema1

#5 para o problema1
IND_SIZE = 5

creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
creator.create("Individual", array.array, typecode='i', fitness=creator.FitnessMin)

toolbox = base.Toolbox()

# Attribute generator
toolbox.register("indices", random.sample, range(IND_SIZE), IND_SIZE)

# Structure initializers
toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.indices)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

def evalTSP(individual):
    distance = distance_map[individual[-1]][individual[0]]
    for gene1, gene2 in zip(individual[0:-1], individual[1:]):
        distance += distance_map[gene1][gene2]
    return distance,

toolbox.register("mate", tools.cxPartialyMatched)
toolbox.register("mutate", tools.mutShuffleIndexes, indpb=0.05)
toolbox.register("select", tools.selTournament, tournsize=3)
toolbox.register("evaluate", evalTSP)

def main():
    populacao = toolbox.population(n=20)
    probabilidade_crossover = 1.0
    probabilidade_mutacao = 0.05
    numero_geracoes = 20
    
    estatisticas = tools.Statistics(key=lambda individuo: individuo.fitness.values)
    estatisticas.register("max", numpy.max)
    estatisticas.register("min", numpy.min)
    estatisticas.register("med", numpy.mean)
    estatisticas.register("std", numpy.std)
    hof = tools.HallOfFame(1)
    
    start = time.time()
    populacao, info = algorithms.eaSimple(populacao, toolbox,
                                          probabilidade_crossover,
                                          probabilidade_mutacao,
                                          numero_geracoes, estatisticas,
                                          )
    end = time.time()
    
    melhores = tools.selBest(populacao, 1)
    for individuo in melhores:
        print(individuo)
        print(individuo.fitness)

    print ("tempo_execucao: {} s".format(end - start))
        
    valores_grafico = info.select("max")
    plt.plot(valores_grafico)
    plt.title("Acompanhamento dos Valores")
    plt.show()

if __name__ == "__main__":
    main()