import xml.etree.ElementTree as ET
import numpy as np
import random as rand


class ReadData:
    def __init__(self, name_of_file):
        self.name_of_file = name_of_file
        try:
            self.tree = ET.parse(name_of_file)
        except FileNotFoundError:
            print("The file does not exist")

    def set_name_of_file(self, name_of_file):
        self.name_of_file = name_of_file

    def set_tree(self, name_of_file):
        try:
            self.tree = ET.parse(name_of_file)
        except FileNotFoundError:
            print("The file does not exist")
        return self.tree

    def get_name_of_file(self):
        return self.name_of_file

    def get_tree(self):
        return self.tree

    @staticmethod
    def get_dimension(data):
        count = 0
        tree = data
        root = tree.getroot()
        for vertex in root.iter('vertex'):
            count += 1

        return count

    @staticmethod
    def create_graph(data, dimension):
        tree = data
        root = tree.getroot()
        arr = np.zeros((dimension, dimension))
        row = 0
        column = 0
        for edge in root.iter('edge'):
            if row == column:
                arr[row][column] = 0
                column += 1

            if row != column:
                arr[row][column] = edge.get('cost')
                column += 1
            if column == dimension:
                column = 0
                row += 1
        return arr


class Ant:
    def __init__(self, ant_id, starting_town):
        self.ant_id = ant_id
        self.starting_town = starting_town
        self.located_town = starting_town
        self.allowed_towns = list()
        self.tour = list()

    def set_ant_id(self, ant_id):
        self.ant_id = ant_id

    def set_starting_town(self, starting_town):
        self.starting_town = starting_town

    def set_located_town(self, located_town):
        self.located_town = located_town

    def set_allowed_towns(self, allowed_towns):
        self.allowed_towns = allowed_towns

    def set_tour(self, town):
        self.tour.append(town)

    def get_ant_id(self):
        return self.ant_id

    def get_starting_town(self):
        return self.starting_town

    def get_located_town(self):
        return self.located_town

    def get_allowed_towns(self):
        return self.allowed_towns

    def get_tour(self):
        return self.tour

    @staticmethod
    def initialize_allowed_towns(dimension):
        allowed_towns = []
        for town in range(0, dimension):
            allowed_towns.append(town)
        return allowed_towns

    @staticmethod
    def transition_probability(located_town, next_town, alpha, beta, pheromone, visibility, allowed_towns):
        if next_town in allowed_towns:
            pheromone_i_j = pheromone[located_town][next_town] ** alpha
            visibility_i = visibility[located_town][next_town] ** beta
            a = pheromone_i_j * visibility_i

            pheromone_all = pheromone[located_town][allowed_towns] ** alpha
            visibility_all = visibility[located_town][allowed_towns] ** beta
            b = sum(pheromone_all * visibility_all)

            return a / b

        else:
            return 0

    @staticmethod
    def compute_tour_length(ant, a_graph):
        length_tour = 0
        for i in range(0, len(a_graph)):
            length_tour += a_graph[ant.get_tour()[i][0]][ant.get_tour()[i][1]]
        return length_tour


class Colony:
    def __init__(self, dimension, a_graph, number_of_ants, alpha, beta, evaporation_rate, number_of_cycles):
        self.dimension = dimension
        self.a_graph = a_graph
        self.number_of_ants = number_of_ants
        self.alpha = alpha
        self.beta = beta
        self.evaporation_rate = evaporation_rate
        self.number_of_cycles = number_of_cycles
        self.ants = list()

    def set_dimension(self, dimension):
        self.dimension = dimension

    def set_graph(self, a_graph):
        self.a_graph = a_graph

    def set_number_of_ants(self, number_of_ants):
        self.number_of_ants = number_of_ants

    def set_alpha(self, alpha):
        self.alpha = alpha

    def set_beta(self, beta):
        self.beta = beta

    def set_evaporation_rate(self, evaporation_rate):
        self.evaporation_rate = evaporation_rate

    def set_number_of_cycles(self, number_of_cycles):
        self.number_of_cycles = number_of_cycles

    def set_ants(self, ants):
        self.ants = ants

    def get_dimension(self):
        return self.dimension

    def get_graph(self):
        return self.a_graph

    def get_number_of_ants(self):
        return self.number_of_ants()

    def get_alpha(self):
        return self.alpha

    def get_beta(self):
        return self.beta

    def get_evaporation_rate(self):
        return self.evaporation_rate

    def get_number_of_cycles(self):
        return self.number_of_cycles

    def get_ants(self):
        return self.ants

    @staticmethod
    def set_visibility(a_graph):
        visibility = 1 / a_graph
        return visibility

    @staticmethod
    def initialize_pheromone(dimension, initial_value):
        initial_pheromone = np.zeros((dimension, dimension))
        for row in range(0, dimension):
            for column in range(0, dimension):
                if row == column:
                    initial_pheromone[row][column] = 0
                else:
                    initial_pheromone[row][column] = initial_value
        return initial_pheromone

    @staticmethod
    def initialize_ants(ants, number_of_ants, dimension):
        for ant_id in range(0, number_of_ants):
            starting_town = rand.randint(0, dimension - 1)
            ants.append(Ant(ant_id, starting_town))
            ants[ant_id].set_allowed_towns(Ant.initialize_allowed_towns(dimension))
            ants[ant_id].get_allowed_towns().remove(ants[ant_id].get_starting_town())
        return ants

    @staticmethod
    def built_tour(ant, alpha, beta, pheromone, visibility, dimension):
        global next_town
        for iteration in range(0, dimension - 1):
            located_town = ant.get_located_town()
            allowed_towns = ant.get_allowed_towns()
            max_probability = 0
            for index in range(0, len(allowed_towns)):
                probability = Ant.transition_probability(located_town, allowed_towns[index], alpha, beta, pheromone,
                                                         visibility,
                                                         allowed_towns)
                if probability > max_probability:
                    max_probability = probability
                    next_town = allowed_towns[index]

            ant.set_tour((ant.located_town, next_town))
            ant.set_located_town(next_town)
            ant.get_allowed_towns().remove(ant.get_located_town())
        ant.set_tour((ant.get_located_town(), ant.get_starting_town()))
        ant.set_located_town(ant.get_starting_town())
        return ant.get_tour()

    @staticmethod
    def quantity_per_unit_of_length_of_pheromone(ants, tour_length, quantity):
        for i in range(0, len(quantity)):
            for j in range(0, len(quantity)):
                for k in range(len(ants)):
                    if (i, j) in ants[k].get_tour():
                        d = 1 / tour_length[k]
                    else:
                        d = 0
                    quantity[i][j] += d
        return quantity

    @staticmethod
    def update_pheromone(pheromone, quantity, evaporation_rate):
        for i in range(0, len(pheromone)):
            for j in range(0, len(pheromone)):
                pheromone[i][j] = evaporation_rate * pheromone[i][j] + quantity[i][j]
        return pheromone

    def run(self):
        min_length_all_time = np.inf
        min_tour = 0
        length_tours = list()
        initial_pheromone = Colony.initialize_pheromone(self.dimension, 1)
        pheromone = initial_pheromone
        quantity = np.zeros((self.dimension, self.dimension))
        visibility = Colony.set_visibility(self.a_graph)
        ants = Colony.initialize_ants(self.ants, self.number_of_ants, self.dimension)
        print("============================Initialize========================================")
        nc = 0
        while nc < self.number_of_cycles:
            for k in range(0, self.number_of_ants):
                ant = ants[k]
                tours = Colony.built_tour(ant, self.alpha, self.beta, pheromone, visibility, self.dimension)
                length_tours.append(Ant.compute_tour_length(ant, self.a_graph))
            quantity = Colony.quantity_per_unit_of_length_of_pheromone(self.ants, length_tours, quantity)
            pheromone = Colony.update_pheromone(pheromone, quantity, self.evaporation_rate)

            min_length = min(length_tours)
            if min_length < min_length_all_time:
                min_length_all_time = min_length
                min_tour = ants[length_tours.index(min(length_tours))].get_tour()
                print(min_length_all_time)
                print(min_tour)

            for k in range(0, self.number_of_ants):
                ants[k].set_allowed_towns(Ant.initialize_allowed_towns(self.dimension))
                ants[k].get_tour().clear()
                length_tours.clear()
                ants[k].set_located_town(ants[k].get_starting_town())
                ants[k].get_allowed_towns().remove(ants[k].get_starting_town())
            nc += 1
        print("Parameters:")
        print("alpha", self.alpha)
        print("beta", self.beta)
        print("evaporation_rate", self.evaporation_rate)
        print("Minimum length:", min_length_all_time, ":", min_tour)


def main():
    read_data = ReadData("data/ulysses16.xml")
    data = read_data.get_tree()
    dimension = ReadData.get_dimension(data)
    graph = ReadData.create_graph(data, dimension)
    print(read_data.get_name_of_file())
    colony = Colony(dimension, graph, 30, 0.7, 0.7, 0.5, 100)
    colony.run()


if __name__ == "__main__":
    main()
