from abc import ABCMeta, abstractmethod
from pathlib import Path
import random
import csv
import itertools
import math
import numpy as np
import matplotlib.pyplot as plt


class Matrix:
    """
    This class obtains a distance matrix from a csv file and stores the coordinates of each node.
    """

    def __init__(self, path_file=''):
        if len(path_file) < 1:
            self.coord_list = self.generate_random_search_space()
        else:
            self.coord_list = self.load_file(path_file)

        self.matrix = self.generate_matrix()

    @classmethod
    def load_file(cls, file):
        """
        Load the given csv file. It should be located in the data folder.
        :returns: list of coordinates of each city
        """

        path_file = get_abs_path('data', file)

        cities_coordinates = []
        try:
            with open(path_file, 'r', encoding='utf-8') as in_file:
                reader = csv.reader(in_file, quoting=csv.QUOTE_NONNUMERIC)

                cities_coordinates.extend(iter(reader))
        except FileNotFoundError as err:
            raise err

        assert cities_coordinates, "Error loading the csv file"

        return cities_coordinates

    def generate_matrix(self):
        """
        Create the distance matrix given a list of coordinates of each city.

        Note: It would be resource efficient to compute and store (N+1)⋅N/2 elements instead of a matrix of N2.
        This would be possible due to the properties of the symmetric matrix. But let's keep it simple by computing the
        whole matrix.

        :returns: distance matrix
        """
        num_of_cities = len(self.coord_list)
        matrix = np.zeros(shape=(num_of_cities, num_of_cities))
        for i, j in itertools.product(range(num_of_cities), range(num_of_cities)):
            if i == j:
                continue
            dist = self.get_dist_two_nodes(self.coord_list, i, j)
            matrix[i][j] = dist
        return matrix

    # functional method
    @staticmethod
    def get_dist_two_nodes(coord_list, node_1, node_2):
        """
        Get the relative distance by applying the Pythagorean theorem.

        :returns: distance between two points
        """
        x_node_1 = coord_list[node_1][0]
        y_node_1 = coord_list[node_1][1]
        x_node_2 = coord_list[node_2][0]
        y_node_2 = coord_list[node_2][1]

        return math.sqrt(pow((x_node_1 - x_node_2), 2) + pow((y_node_1 - y_node_2), 2))

    @staticmethod
    def generate_random_search_space(nodes=25):
        """
        Generate a randomly generated search space given the number of nodes.
        :returns: list of coordinates of each node (city)
        """
        np.random.seed(42)

        coord = []
        for _ in range(nodes):
            x_node = np.random.uniform(0, 100)
            y_node = np.random.uniform(0, 100)
            coord.append([x_node, y_node])

        return coord


ROOT_DIR = Path(__file__).parents[3]


def get_abs_path(*path):
    """
    Get absolute path from a given file based on the root directory of the project
    """
    return ROOT_DIR.joinpath(*path)


def get_operator_by_name(op_name):
    ops_dict = {'rand_swap': RandomSwap(),
                'rand_swap_adj': RandomSwapAdjacent(),
                'inversion': Inversion(),
                'two_opt': TwoOpt(),
                'three_opt': ThreeOpt()}

    return ops_dict.get(op_name) or ops_dict.get('rand_swap')


class Operator:
    """
    Abstract class to be inherited by the different operators (random_swap, two-opt, inversion...)
    """
    __metaclass__ = ABCMeta

    @abstractmethod
    def generate_candidate_solution(self, path: list) -> None:
        """
        Given a list, generate a candidate solution based on the operator type.
        """
        return

    # functional methods
    @classmethod
    def get_random_index(cls, range_list, num_indexes):
        """
        Get one or more randomly selected indexes from a given list.
        """
        assert num_indexes != 0, 'The number of indexes cannot be 0. It must be 1 or greater.'

        if num_indexes == 1:
            return random.randrange(range_list)

        assert num_indexes < range_list, 'More indexes to return than the size of current list.'

        ret = [random.randrange(range_list)]

        for _ in range(num_indexes - 1):
            next_rand_node = random.randrange(range_list)

            # Ensure that next_rand_node is not the same as the other random nodes generated
            while next_rand_node in ret:
                next_rand_node = random.randrange(range_list)

            ret.append(next_rand_node)

        return ret


class RandomSwap(Operator):
    """Random Exchange"""

    def generate_candidate_solution(self, path):
        """
        Exchange two randomly selected (not necessarily adjacent) nodes.
        """
        node_a, node_b = self.get_random_index(len(path), 2)

        path[node_a], path[node_b] = path[node_b], path[node_a]

        return path


class RandomSwapAdjacent(Operator):
    """Random Exchange Adjacent"""

    def generate_candidate_solution(self, path):
        """
        Exchange two randomly selected adjacent nodes.
        """
        node_a = self.get_random_index(len(path) - 1, 1)
        node_b = node_a + 1

        path[node_a], path[node_b] = path[node_b], path[node_a]

        return path


class Inversion(Operator):
    """Inversion"""

    def generate_candidate_solution(self, path):
        """
        Invert the sub-array contained within two randomly selected nodes.
        """
        node_a, node_b = sorted(self.get_random_index(len(path), 2))

        diff = node_b - node_a + 1

        for i in range(diff // 2):
            path[node_a + i], path[node_b - i] = path[node_b - i], path[node_a + i]

        return path


class TwoOpt(Operator):
    """2-Opt"""

    def generate_candidate_solution(self, path):
        """
        Remove randomly 2 edges and replace all the possible permutations.
        """

        node_a = self.get_random_index(len(path) - 1, 1)
        node_b = node_a + 1

        node_c = self.get_random_index(len(path) - 1, 1)

        while node_c == node_a:
            node_c = self.get_random_index(len(path) - 1, 1)

        # In 2-opt operator there are 4 possible permutations, 2 of which are the same
        # but with opposite directions.
        # Then only one permutation is to be compared with the original path

        # Swap node_b and node_c:
        path[node_b], path[node_c] = path[node_c], path[node_b]

        return path


class ThreeOpt(Operator):
    """3-Opt"""

    def generate_candidate_solution(self, path):
        """
        Remove randomly 3 edges and replace all the possible permutations.
        """
        return


class Algorithm:
    """
    Abstract class to be inherited by TS, SA and GA. It contains basic members related to TSP.
    """
    __metaclass__ = ABCMeta

    def __init__(self, file, stop, n_op):
        self.matrix = Matrix(file)
        self.x_coord, self.y_coord = zip(*self.matrix.coord_list)

        self.x_min, self.x_max = min(self.x_coord), max(self.x_coord)
        self.y_min, self.y_max = min(self.y_coord), max(self.y_coord)

        self.nodes = len(self.matrix.matrix[0])
        self.stop = stop
        self.n_op = get_operator_by_name(n_op)

        self.cycles = 0

    @abstractmethod
    def run(self):
        """
        Run the algorithm until the stopping criterion is met.
        """
        return

    def generate_init_candidate(self, random_init=True):
        """
        Generate an initial solution given the search space.
        """
        init_solution = []
        if random_init:
            init_solution = random.sample(range(self.nodes), self.nodes)
        else:
            # TODO: greedy start
            pass

        assert len(set(init_solution)) == self.nodes, \
            f'The randomly generated initial solution does not contain all the {self.nodes} items'
        return init_solution

    def evaluate_solution(self, tour):
        """
        Calculate the cost of the given solution based on the matrix of distances
        """
        cost = sum(self.matrix.matrix[tour[i]][tour[i + 1]] for i in range(len(tour) - 1))

        cost += self.matrix.matrix[tour[-1]][tour[0]]
        return cost

    def plot_path(self, tour, title='', subtitle=''):
        """
        Plot the given path of nodes to visualise the result.
        """
        plt.xlim(self.x_min - self.x_max * 0.1, self.x_max + self.x_max * 0.1)
        plt.ylim(self.y_min - self.y_max * 0.1, self.y_max + self.y_max * 0.1)

        plt.scatter(self.x_coord, self.y_coord, color='black')

        path_x = [self.x_coord[val] for val in tour]
        path_y = [self.y_coord[val] for val in tour]

        # adding the last city to come back to the starting point
        path_x.append(path_x[0])
        path_y.append(path_y[0])

        plt.suptitle(title, fontsize=16)
        plt.title(subtitle, fontsize=14)

        plt.plot(path_x, path_y, color='green')

    def plot_search_space(self, title='', subtitle=''):
        """
        Plot search space of all the cities without the tours.
        """
        plt.rcParams["figure.figsize"] = (10, 8)
        plt.tight_layout()
        plt.xlim(self.x_min - self.x_max * 0.1, self.x_max + self.x_max * 0.1)
        plt.ylim(self.y_min - self.y_max * 0.1, self.y_max + self.y_max * 0.1)

        plt.suptitle(title, fontsize=16)
        plt.title(subtitle, fontsize=14)

        plt.scatter(self.x_coord, self.y_coord, color='black')
        plt.show()

    @staticmethod
    def plot_convergence(costs_list, title, x_label='', y_label=''):
        """
        Plot learning process (decrease of travelling cost) of algorithm over time.
        """
        plt.suptitle(title, fontsize=16)
        plt.xlabel(x_label, fontsize=12)
        plt.ylabel(y_label, fontsize=12)
        plt.plot(costs_list)
        plt.show()


class SimulatedAnnealing(Algorithm):
    """Simulated Annealing Algorithm"""

    def __init__(self, file='', stop=100, operator="inversion", t_max=10, t_min=0.0005, alpha=0.995,
                 cooling_schedule='slow'):
        super().__init__(file, stop, operator)
        self.t_max = t_max
        self.t_min = t_min
        self.current_temp = t_max
        self.alpha = alpha

        self.cooling_schedules_dict = {
            'linear': lambda: self.current_temp - self.alpha,
            'geometric': lambda: self.current_temp * self.alpha,
            'slow': lambda: self.current_temp / (1 + self.alpha * self.current_temp),
            'exp_mult': lambda: self.current_temp * math.pow(self.alpha, self.cycles),
            'linear_mult': lambda: self.current_temp / (1 + self.alpha * self.cycles),
            'quad_mult': lambda: self.current_temp / (1 + self.alpha * math.pow(self.cycles, 2)),
            'log_mult': lambda: self.current_temp / (1 + self.alpha * math.log(1 + self.cycles))
        }

        self.decrease_temperature = self.cooling_schedules_dict.get(cooling_schedule)

    def run(self):
        """
        Run the Simulated Annealing algorithm to stop when T < Tmin.
        The algorithm generates candidates based on the selected neighbourhood
        operator and will tend to accept less bad moves over time,
        according to the acceptance probability.
        """
        print(f'\nRunning {self.__doc__}. Stopping if no improvement after {self.stop} iterations \n')
        best_solution = self.generate_init_candidate()
        best_cost = self.evaluate_solution(best_solution)
        self.current_temp = self.t_max
        cost_candidates = [best_cost]

        plt.rcParams["figure.figsize"] = (10, 8)
        plt.tight_layout()

        count = 0
        while self.t_min < self.current_temp and count < self.stop:
            solution_candidate = self.n_op.generate_candidate_solution(best_solution.copy())
            cost_candidate = self.evaluate_solution(solution_candidate)

            acc_prob = self.calculate_acceptance_probability(best_cost, cost_candidate)

            if acc_prob > random.random():
                best_solution = solution_candidate.copy()
                best_cost = cost_candidate
                cost_candidates.append(cost_candidate)

                plt.cla()
                self.plot_path(best_solution, f'{self.__doc__} using {self.n_op.__doc__}',
                               f'Iteration: {self.cycles} \nCost: {round(best_cost)}')
                plt.pause(0.05)
                count = 0

            self.cycles += 1
            count += 1

            self.current_temp = self.decrease_temperature()

        plt.show(block=True)

        self.plot_convergence(cost_candidates, f'{self.__doc__} minimisation convergence',
                              x_label=f'Total iterations: {self.cycles}', y_label='Cost')

    def calculate_acceptance_probability(self, cost_1, cost_2):
        """
        Acceptance probability = e(-∆E/T), being ∆E=C(S1)-C(S2)
        """
        if cost_1 > cost_2:  # new candidate is already better than current solution
            return 1.0

        return math.exp((cost_1 - cost_2) / self.current_temp)


sa = SimulatedAnnealing(alpha=0.995, cooling_schedule='slow', file='', operator='inversion', stop=100, t_max=10,
                   t_min=0.0005)
sa.run()