import copy

def main():
    # Algoritmo A*
    # Vítor Rodrigues Gôngora - RA106769

    # g = custo de mover a peça (1)
    # h = Distancia manhattan (distancia dos eixos x e y)
    # f = (g anterior + g) + h
    
    # O algoritmo busca escolher o próximo nó de modo
    # a escolher o menor f

    # Problema de pathfinding
    # "O" = Personagem
    # " " = Caminho livre

    # Destino dado em x, y
    
    # 0 --------> 5
    # |
    # |
    # |
    # \/
    # 5

    # Exemplo:
    estado_inicial = \
    [
        ["O", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " "]
     ]
    
    # Estado final:
    # [
    #     [" ", " ", " ", " ", " ", " "],
    #     [" ", " ", " ", " ", " ", " "],
    #     [" ", " ", " ", " ", " ", " "],
    #     [" ", " ", " ", " ", " ", " "],
    #     [" ", " ", " ", " ", " ", " "],
    #     [" ", " ", " ", " ", " ", "O"]
    #  ]
    
    destino_x, destino_y = 5, 5
    pos_x, pos_y = 0, 0
    
    instancia = copy.deepcopy(estado_inicial)
    g_atual = 0

    while(pos_x != destino_x or pos_y != destino_y):
        print("\nInstancia = \n")
        for i in instancia:
            print(i)
        
        movimentos = movimentos_possiveis(instancia)
        f = [g_atual] * len(movimentos)

        for i in range(0, len(movimentos)):
            h = distancia_manhattan(movimentos[i], destino_x, destino_y)
            f[i] = f[i] + h
        
        instancia = movimentos[f.index(min(f))]

        print("\nMovimentos possiveis = \n")
        for i in movimentos:
            print("")
            for j in i:
                print(j)

        print("f = ", f)
        g_atual = g_atual + 1

        for i in range(0, len(instancia)):
            for j in range(0, len(instancia)):
                if(instancia[i][j] == "O"):
                    pos_x = i
                    pos_y = j

    print("\nInstancia = \n")
    for i in instancia:
            print(i)
        
def distancia_manhattan(movimento, dest_x, dest_y):
    pos_x, pos_y = 0, 0
    for i in range(0, len(movimento)):
        for j in range(0, len(movimento)):
            if(movimento[i][j] == "O"):
                pos_x = i
                pos_y = j

    return abs(pos_x - dest_x) + abs(pos_y - dest_y)

def movimentos_possiveis(instancia):
    pers_x = 0
    pers_y = 0
    movimentos = []
    idx_maximo = len(instancia) - 1

    for i in range(0, len(instancia)):
        for j in range(0, len(instancia)):
            if instancia[i][j] == "O":
                pers_x = i
                pers_y = j

    movimentos = []
    # Verifica se está em um dos cantos
    if pers_x == 0 and pers_y == 0:
        
        if instancia[0][1] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[0][0] = " "
            novo_movimento1[0][1] = "O"
            movimentos.append(novo_movimento1)

        if instancia[1][0] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[0][0] = " "
            novo_movimento2[1][0] = "O"
            movimentos.append(novo_movimento2)

        return movimentos
    
    elif pers_x == idx_maximo and pers_y == 0:
        if instancia[idx_maximo - 1][0] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[idx_maximo][0] = " "
            novo_movimento1[idx_maximo - 1][0] = "O"
            movimentos.append(novo_movimento1)

        if instancia[idx_maximo][1] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[idx_maximo][0] = " "
            novo_movimento2[idx_maximo][1] = "O"
            movimentos.append(novo_movimento2)
        return movimentos
    
    elif pers_x == 0 and pers_y == idx_maximo:
        if instancia[0][idx_maximo - 1] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[0][idx_maximo] = " "
            novo_movimento1[0][idx_maximo - 1] = "O"
            movimentos.append(novo_movimento1)

        if instancia[1][idx_maximo] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[0][idx_maximo] = " "
            novo_movimento2[1][idx_maximo] = "O"
            movimentos.append(novo_movimento2)
        return movimentos
    
    elif pers_x == idx_maximo and pers_y == idx_maximo:
        if instancia[idx_maximo][idx_maximo - 1] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[idx_maximo][idx_maximo] = " "
            novo_movimento1[idx_maximo][idx_maximo - 1] = "O"
            movimentos.append(novo_movimento1)

        if instancia[idx_maximo - 1][idx_maximo] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[idx_maximo][idx_maximo] = " "
            novo_movimento2[idx_maximo - 1][idx_maximo] = "O"
            movimentos.append(novo_movimento2)
        return movimentos
    
    elif pers_x == 0:
        if instancia[0][pers_y - 1] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[0][pers_y] = " "
            novo_movimento1[0][pers_y - 1] = "O"
            movimentos.append(novo_movimento1)

        if instancia[0][pers_y + 1] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[0][pers_y] = " "
            novo_movimento2[0][pers_y + 1] = "O"
            movimentos.append(novo_movimento2)

        if instancia[1][pers_y] != "X":
            novo_movimento3 = copy.deepcopy(instancia)
            novo_movimento3[0][pers_y] = " "
            novo_movimento3[1][pers_y] = "O"
            movimentos.append(novo_movimento3)
        return movimentos
    
    elif pers_x == idx_maximo:
        if instancia[idx_maximo][pers_y - 1] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[idx_maximo][pers_y] = " "
            novo_movimento1[idx_maximo][pers_y - 1] = "O"
            movimentos.append(novo_movimento1)

        if instancia[idx_maximo][pers_y + 1] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[idx_maximo][pers_y] = " "
            novo_movimento2[idx_maximo][pers_y + 1] = "O"
            movimentos.append(novo_movimento2)

        if instancia[idx_maximo - 1][pers_y] != "X":
            novo_movimento3 = copy.deepcopy(instancia)
            novo_movimento3[idx_maximo][pers_y] = " "
            novo_movimento3[idx_maximo - 1][pers_y] = "O"
            movimentos.append(novo_movimento3)
        return movimentos
    
    elif pers_y == 0:
        if instancia[pers_x - 1][0] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[pers_x][0] = " "
            novo_movimento1[pers_x - 1][0] = "O"
            movimentos.append(novo_movimento1)

        if instancia[pers_x + 1][0] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[pers_x][0] = " "
            novo_movimento2[pers_x + 1][0] = "O"
            movimentos.append(novo_movimento2)

        if instancia[pers_x][pers_y + 1] != "X":
            novo_movimento3 = copy.deepcopy(instancia)
            novo_movimento3[pers_x][0] = " "
            novo_movimento3[pers_x][pers_y + 1] = "O"
            movimentos.append(novo_movimento3)
        return movimentos
    
    elif pers_y == idx_maximo:
        if instancia[pers_x - 1][idx_maximo] != "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[pers_x][idx_maximo] = " "
            novo_movimento1[pers_x - 1][idx_maximo] = "O"
            movimentos.append(novo_movimento1)

        if instancia[pers_x + 1][idx_maximo] != "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[pers_x][idx_maximo] = " "
            novo_movimento2[pers_x + 1][idx_maximo] = "O"
            movimentos.append(novo_movimento2)

        if instancia[pers_x][pers_y - 1]!= "X":
            novo_movimento3 = copy.deepcopy(instancia)
            novo_movimento3[pers_x][idx_maximo] = " "
            novo_movimento3[pers_x][pers_y - 1] = "O"
            movimentos.append(novo_movimento3)
        return movimentos

    else:
        if instancia[pers_x - 1][pers_y]!= "X":
            novo_movimento1 = copy.deepcopy(instancia)
            novo_movimento1[pers_x][pers_y] = " "
            novo_movimento1[pers_x - 1][pers_y] = "O"
            movimentos.append(novo_movimento1)

        if instancia[pers_x + 1][pers_y]!= "X":
            novo_movimento2 = copy.deepcopy(instancia)
            novo_movimento2[pers_x][pers_y] = " "
            novo_movimento2[pers_x + 1][pers_y] = "O"
            movimentos.append(novo_movimento2)

        if instancia[pers_x][pers_y - 1]!= "X":
            novo_movimento3 = copy.deepcopy(instancia)
            novo_movimento3[pers_x][pers_y] = " "
            novo_movimento3[pers_x][pers_y - 1] = "O"
            movimentos.append(novo_movimento3)

        if instancia[pers_x][pers_y + 1]!= "X":
            novo_movimento4 = copy.deepcopy(instancia)
            novo_movimento4[pers_x][pers_y] = " "
            novo_movimento4[pers_x][pers_y + 1] = "O"
            movimentos.append(novo_movimento4)
        return movimentos

main()

        
        


    