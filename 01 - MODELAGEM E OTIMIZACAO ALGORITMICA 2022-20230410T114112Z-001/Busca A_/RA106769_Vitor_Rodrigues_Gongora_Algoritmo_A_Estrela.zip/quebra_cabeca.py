import copy

def main():
    # Algoritmo A*
    # Vítor Rodrigues Gôngora - RA106769

    # g = custo de mover a peça (1)
    # h = Distancia manhattan (distancia dos eixos x e y)
    # f = (g anterior + g) + h
    
    # O algoritmo busca escolher o próximo nó de modo
    # a escolher o menor f

    # Problema de quebra-cabeça de 8 peças
    # Exemplo:
    
    estado_final = \
    [[1, 2, 3],
     [8, None, 4],
     [7, 6, 5]]

    estado_inicial = \
    [[2, 8, 3],
     [1, 6, 4],
     [7, None, 5]]
    
    instancia = copy.deepcopy(estado_inicial)
    g_atual = 0

    while(numero_pecas_fora_lugar(instancia, estado_final) > 0):
        print("\nInstancia = ")
        for i in instancia:
            print(i)

        movimentos = movimentos_possiveis(instancia)

        f = [g_atual] * len(movimentos)

        for i in range(0, len(movimentos)):
            h = numero_pecas_fora_lugar(movimentos[i], estado_final)
            f[i] = f[i] + h
        
        instancia = movimentos[f.index(min(f))]

        print("\nMovimentos possiveis =")
        for i in movimentos:
            print("")
            for j in i:
                print(j)

        print("\nf = ", f)
        g_atual = g_atual + 1

    print("\nInstancia = ")
    for i in instancia:
            print(i)
        


def numero_pecas_fora_lugar(instancia, estado_final):
    sol = estado_final
    
    fora_lugar_count = 0
    
    for i in range(0, len(sol)):
        for j in range(0, len(sol)):
            if(instancia[i][j] != sol[i][j]):
                fora_lugar_count = fora_lugar_count + 1
    
    return fora_lugar_count

def movimentos_possiveis(instancia):
    none_x = 0
    none_y = 0
    movimentos = []
    idx_maximo = len(instancia) - 1

    for i in range(0, len(instancia)):
        for j in range(0, len(instancia)):
            if instancia[i][j] == None:
                none_x = i
                none_y = j

    movimentos = []
    # Verifica se está em um dos cantos
    if none_x == 0 and none_y == 0:
        
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[0][0] = novo_movimento1[0][1]
        novo_movimento1[0][1] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[0][0] = novo_movimento2[1][0]
        novo_movimento2[1][0] = None
        movimentos.append(novo_movimento2)
        return movimentos
    
    elif none_x == idx_maximo and none_y == 0:
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[idx_maximo][0] = novo_movimento1[idx_maximo - 1][0]
        novo_movimento1[idx_maximo - 1][0] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[idx_maximo][0] = novo_movimento2[idx_maximo][1]
        novo_movimento2[idx_maximo][1] = None
        movimentos.append(novo_movimento2)
        return movimentos
    
    elif none_x == 0 and none_y == idx_maximo:
        
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[0][idx_maximo] = novo_movimento1[0][idx_maximo - 1]
        novo_movimento1[0][idx_maximo - 1] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[0][idx_maximo] = novo_movimento2[1][idx_maximo]
        novo_movimento2[1][idx_maximo] = None
        movimentos.append(novo_movimento2)
        return movimentos
    
    elif none_x == idx_maximo and none_y == idx_maximo:
        
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[idx_maximo][idx_maximo] = novo_movimento1[idx_maximo][idx_maximo - 1]
        novo_movimento1[idx_maximo][idx_maximo - 1] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[idx_maximo][idx_maximo] = novo_movimento2[idx_maximo - 1][idx_maximo]
        novo_movimento2[idx_maximo - 1][idx_maximo] = None
        movimentos.append(novo_movimento2)
        return movimentos
    
    elif none_x == 0:
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[0][none_y] = novo_movimento1[0][none_y - 1]
        novo_movimento1[0][none_y - 1] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[0][none_y] = novo_movimento2[0][none_y + 1]
        novo_movimento2[0][none_y + 1] = None
        movimentos.append(novo_movimento2)

        novo_movimento3 = copy.deepcopy(instancia)
        novo_movimento3[0][none_y] = novo_movimento3[1][none_y]
        novo_movimento3[1][none_y] = None
        movimentos.append(novo_movimento3)
        return movimentos
    
    elif none_x == idx_maximo:
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[idx_maximo][none_y] = novo_movimento1[0][none_y - 1]
        novo_movimento1[idx_maximo][none_y - 1] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[idx_maximo][none_y] = novo_movimento2[0][none_y + 1]
        novo_movimento2[idx_maximo][none_y + 1] = None
        movimentos.append(novo_movimento2)

        novo_movimento3 = copy.deepcopy(instancia)
        novo_movimento3[idx_maximo][none_y] = novo_movimento3[idx_maximo - 1][none_y]
        novo_movimento3[idx_maximo - 1][none_y] = None
        movimentos.append(novo_movimento3)
        return movimentos
    
    elif none_y == 0:
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[none_x][0] = novo_movimento1[none_x - 1][0]
        novo_movimento1[none_x - 1][0] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[none_x][0] = novo_movimento2[none_x + 1][0]
        novo_movimento2[none_x + 1][0] = None
        movimentos.append(novo_movimento2)

        novo_movimento3 = copy.deepcopy(instancia)
        novo_movimento3[none_x][0] = novo_movimento3[none_x][none_y + 1]
        novo_movimento3[none_x][none_y + 1] = None
        movimentos.append(novo_movimento3)
        return movimentos
    
    elif none_y == idx_maximo:
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[none_x][idx_maximo] = novo_movimento1[none_x - 1][0]
        novo_movimento1[none_x - 1][0] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[none_x][idx_maximo] = novo_movimento2[none_x + 1][0]
        novo_movimento2[none_x + 1][0] = None
        movimentos.append(novo_movimento2)

        novo_movimento3 = copy.deepcopy(instancia)
        novo_movimento3[none_x][idx_maximo] = novo_movimento3[none_x][none_y - 1]
        novo_movimento3[none_x][none_y - 1] = None
        movimentos.append(novo_movimento3)
        return movimentos

    else:
        novo_movimento1 = copy.deepcopy(instancia)
        novo_movimento1[none_x][none_y] = novo_movimento1[none_x - 1][none_y]
        novo_movimento1[none_x - 1][none_y] = None
        movimentos.append(novo_movimento1)

        novo_movimento2 = copy.deepcopy(instancia)
        novo_movimento2[none_x][none_y] = novo_movimento2[none_x + 1][none_y]
        novo_movimento2[none_x + 1][none_y] = None
        movimentos.append(novo_movimento2)

        novo_movimento3 = copy.deepcopy(instancia)
        novo_movimento3[none_x][none_y] = novo_movimento3[none_x][none_y - 1]
        novo_movimento3[none_x][none_y - 1] = None
        movimentos.append(novo_movimento3)

        novo_movimento4 = copy.deepcopy(instancia)
        novo_movimento4[none_x][none_y] = novo_movimento4[none_x][none_y + 1]
        novo_movimento4[none_x][none_y + 1] = None
        movimentos.append(novo_movimento4)
        return movimentos

main()

        
        


    