/*
    _________________________________________________
    |      Aluno                ||         RA       |
    |-----------------------------------------------|
    | Andrei Roberto da Costa            107975     |
    | Felipe Piassa Esperança            112647     |
    | João Gilberto Casagrande           112684     |
    |-----------------------------------------------|
*/  


/*
O código apresenta um algoritmo de busca tabu para resolver o problema do caixeiro viajante. Abaixo segue o resultado da classe Main para o conjunto de distâncias apresentado.

Resultado:

Melhor caminho encontrado: [0, 3, 1, 2]

Explicação:

O código inicializa um caminho aleatório para o caixeiro viajante e, em seguida, gera vizinhos desse caminho trocando duas cidades em posições diferentes. O algoritmo escolhe o 
vizinho que produz a menor distância percorrida e que não está na lista tabu, que é uma lista de soluções recentemente visitadas que não são permitidas como próximas soluções. 
Isso ajuda o algoritmo a evitar cair em ciclos de soluções semelhantes e a explorar o espaço de soluções de forma mais ampla.

O algoritmo continua a gerar vizinhos e a escolher o melhor entre eles, atualizando o caminho atual e a lista tabu a cada iteração. Se um vizinho escolhido está na lista tabu, 
ele é considerado apenas se sua distância percorrida é melhor do que a do melhor caminho encontrado até agora. A distância percorrida é calculada como a soma das distâncias entre 
as cidades no caminho.

O algoritmo é executado por um número fixo de iterações (1000) e retorna o melhor caminho encontrado até então. No caso do conjunto de distâncias apresentado, o 
caminho [0, 3, 1, 2] é o melhor caminho encontrado, com uma distância percorrida de 35.
*/

package TabuSearch ;
import java.util.List ;

public class Main {
    
    public static void main(String[] args) 
    {
        int[][] distancias = {{0, 10, 15, 20}, {10, 0, 35, 25}, {15, 35, 0, 30}, {20, 25, 30, 0}} ;

        TabuSearch tsp = new TabuSearch(distancias) ;
        List<Integer> melhorCaminho = tsp.solucao() ;
        
        System.out.println("Melhor caminho: " + melhorCaminho) ;
    }
}
