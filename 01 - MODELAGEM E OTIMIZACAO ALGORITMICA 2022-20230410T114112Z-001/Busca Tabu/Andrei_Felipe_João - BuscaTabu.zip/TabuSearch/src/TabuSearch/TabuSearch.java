/*
    _________________________________________________
    |      Aluno                ||         RA       |
    |-----------------------------------------------|
    | Andrei Roberto da Costa            107975     |
    | Felipe Piassa Esperança            112647     |
    | João Gilberto Casagrande           112684     |
    |-----------------------------------------------|

*/  

package TabuSearch;

import java.util.* ;


/*
    A classe TabuSearch em Java é uma implementação do algoritmo Tabu Search, que é um algoritmo de otimização usado para resolver problemas de combinação, como o problema do 
    caixeiro-viajante. O algoritmo mantém uma lista tabu para evitar soluções repetidas e força a exploração de soluções novas. A implementação usa uma matriz 
    de distâncias, que armazena a distância entre cada par de cidades, e um caminho de solução representado como uma matriz de inteiros.
*/
public class TabuSearch 
{
    
    // A classe tem três atributos privados: uma matriz de distâncias, um tamanho da matriz e uma lista de inteiros para armazenar o melhor caminho encontrado.  
    private int[][] distancias ;
    private int tamanho ;
    private List<Integer> melhorCaminho ;

    // O construtor da classe recebe a matriz de distâncias e inicializa o tamanho e a lista de soluções.
    public TabuSearch(int[][] distancias) 
    {
        this.distancias = distancias ;
        this.tamanho = distancias.length ;
        this.melhorCaminho = new ArrayList<Integer>() ;
    }
    
    /*
        A classe possui um método público chamado solucao(), que executa a busca tabu. O método começa inicializando algumas variáveis, incluindo o número máximo de 
        iterações, o tamanho da lista tabu e o caminho atual. O caminho atual é inicializado aleatoriamente, e o melhor caminho é definido como o caminho atual. O algoritmo então 
        começa a busca tabu, que consiste em : Gerar vizinhos do caminho atual, selecionar o vizinho com a melhor distância e atualizar o caminho atual e a lista tabu.
    */
    public List<Integer> solucao() 
    {
        int iteracoes = 1000 ; // Número máximo de iterações
        int tamanhoListaTabu = 10 ; // Tamanho da lista tabu
        int[] caminhoAtual = new int[tamanho] ;
        int[] melhorCaminhoEncontrado = new int[tamanho] ;
        int distanciaAtual, melhorDistanciaEncontrada ;
        List<Integer> listaTabu = new LinkedList<Integer>() ;

        // Inicializa o caminho atual aleatoriamente
        for (int i = 0; i < tamanho; i++) 
        {
            caminhoAtual[i] = i ;
        }
        
        // Chama o método auxiliar "shuffleArray", que tem o intuito de embaralhar um array de inteiros, no caso, 'caminhoAtual' .
        shuffleArray(caminhoAtual) ;

        // Inicializa o melhor caminho encontrado .
        System.arraycopy(caminhoAtual, 0, melhorCaminhoEncontrado, 0, tamanho) ;
        melhorDistanciaEncontrada = calculaDistancia(melhorCaminhoEncontrado) ;

        // Começa a busca tabu .
        for (int i = 0; i < iteracoes; i++) 
        {
            int[] novoCaminho = new int[tamanho] ;
            int melhorTrocaI = -1, melhorTrocaJ = -1 ;
            int melhorDistanciaVizinho = Integer.MAX_VALUE ;

            // Gera vizinhos do caminho atual
            for (int j = 0; j < tamanho; j++) 
            {
                for (int k = j + 1; k < tamanho; k++) 
                {
                    int[] vizinho = trocaCidades(caminhoAtual, j, k) ;
                    int distanciaVizinho = calculaDistancia(vizinho) ;

                    // Verifica se o vizinho não está na lista tabu
                    if (!listaTabu.contains(Arrays.hashCode(vizinho))) 
                    {
                        if (distanciaVizinho < melhorDistanciaVizinho) 
                        {
                            melhorDistanciaVizinho = distanciaVizinho ;
                            melhorTrocaI = j ;
                            melhorTrocaJ = k ;
                            novoCaminho = vizinho ;
                        }
                    }
                }
            }

            // Atualiza o caminho atual e a lista tabu .
            if (melhorTrocaI != -1 && melhorTrocaJ != -1) 
            {
                System.arraycopy(novoCaminho, 0, caminhoAtual, 0, tamanho) ;
                listaTabu.add(Arrays.hashCode(novoCaminho)) ;

                if (listaTabu.size() > tamanhoListaTabu) 
                {
                    listaTabu.remove(0) ; 
                }

                // Verifica se o vizinho é melhor do que o melhor caminho encontrado .
                distanciaAtual = calculaDistancia(caminhoAtual) ;
                if (distanciaAtual < melhorDistanciaEncontrada) 
                {
                    melhorDistanciaEncontrada = distanciaAtual ;
                    System.arraycopy(caminhoAtual, 0, melhorCaminhoEncontrado, 0, tamanho) ;
                    melhorCaminho = Arrays.asList(Arrays.stream(melhorCaminhoEncontrado).boxed().toArray(Integer[]::new)) ;
                }

                // Realiza a troca das cidades no caminho atual .
                caminhoAtual = trocaCidades(caminhoAtual, melhorTrocaI, melhorTrocaJ) ;
            }
        }
        return melhorCaminho ;
    }

    // Método auxiliar : 'shuffleArray' -> Tem como intuito embaralhar um array .
    private void shuffleArray(int[] array) 
    {
        Random rnd = new Random() ;
        
        for (int i = array.length - 1; i > 0; i--) 
        {
            int index = rnd.nextInt(i + 1) ;
            int temp = array[index] ;
            array[index] = array[i] ;
            array[i] = temp ;
        }
    }

    // Calcula a distância total do caminho .
    private int calculaDistancia(int[] caminho) 
    {
        int distancia = 0 ;
        
        for (int i = 0; i < tamanho - 1; i++) 
        {
            distancia += distancias[caminho[i]][caminho[i + 1]] ;
        }
        
        distancia += distancias[caminho[tamanho - 1]][caminho[0]] ;
        
        return distancia ;
    }

    // Troca as cidades na posição i e j do caminho .
    private int[] trocaCidades(int[] caminho, int i, int j) 
    {
        if (caminho == null || caminho.length == 0) 
        {
            throw new IllegalArgumentException("Caminho inválido: " + Arrays.toString(caminho));
        }
        
        int[] novoCaminho = new int[tamanho] ;
        System.arraycopy(caminho, 0, novoCaminho, 0, tamanho) ;
        int temp = novoCaminho[i] ;
        novoCaminho[i] = novoCaminho[j] ;
        novoCaminho[j] = temp ;
        
        return novoCaminho ;
    }
}