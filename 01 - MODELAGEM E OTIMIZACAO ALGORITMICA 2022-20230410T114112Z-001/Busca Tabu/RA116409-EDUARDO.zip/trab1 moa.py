#EDUARDO ANDRADE MANFRE RA116409

#Implementação da Busca Tabu para um problema de otimização combinatória, especificamente o Problema 
#do Caixeiro Viajante (TSP - Traveling Salesman Problem). O objetivo do TSP é encontrar o caminho mais 
#curto que passa por todas as cidades exatamente uma vez e retorna à cidade de origem. É um problema 
#NP-difícil, o que significa que não há algoritmo conhecido que possa resolvê-lo de forma eficiente para todas as instâncias.

#A Busca Tabu é uma técnica heurística que ajuda a escapar de mínimos locais em problemas de otimização 
#combinatória. Ela mantém uma lista de soluções recentemente visitadas (a lista tabu) e evita revisitar 
#essas soluções, permitindo que a busca explore outras áreas da solução. O algoritmo tenta encontrar uma 
#solução ótima modificando iterativamente a solução atual para criar vizinhos, avaliando cada vizinho 
#para determinar se é melhor do que a solução atual e, em seguida, selecionando o melhor vizinho que não 
#está na lista tabu. A lista tabu ajuda a evitar soluções estagnadas e fornece uma estratégia para escapar de mínimos locais.

#No código, a função tsp_search implementa a Busca Tabu para o TSP. Ela recebe como entrada uma lista de 
#cidades (representadas por coordenadas x, y), o número máximo de iterações e o tamanho da lista tabu. A 
#função inicializa as variáveis necessárias, incluindo a melhor solução e o melhor custo, e itera até o 
#número máximo de iterações. Em cada iteração, a função gera vizinhos, avalia cada vizinho para determinar 
#o seu custo e seleciona o melhor vizinho que não está na lista tabu. A lista tabu é atualizada com a melhor 
#solução encontrada, e se a lista tabu ficar maior que o tamanho especificado, a solução mais antiga é 
#removida. A função retorna a melhor solução e o seu custo.

#As funções generate_neighbors e calculate_cost auxiliam a função tsp_search na geração de vizinhos e cálculo 
#do custo de uma solução, respectivamente. A função distance calcula a distância euclidiana entre duas cidades.

import random

def tsp_search(cities, max_iter, tabu_size):
    best_solution = None
    best_cost = float('inf')
    tabu_list = []
    iter_count = 0

    # loop principal
    while iter_count < max_iter:
        neighbors = generate_neighbors(cities, tabu_list)
        
        for neighbor in neighbors:
            cost = calculate_cost(neighbor)
            if cost < best_cost:
                best_solution = neighbor
                best_cost = cost
        tabu_list.append(best_solution)
        if len(tabu_list) > tabu_size:
            tabu_list.pop(0)
        iter_count += 1

    return best_solution, best_cost

# gera todas as possíveis trocas de nós e retorna apenas as que não estão na lista tabu
def generate_neighbors(cities, tabu_list):
    neighbors = []
    for i in range(len(cities)):
        for j in range(i+1, len(cities)):
            neighbor = cities[:]
            neighbor[i], neighbor[j] = neighbor[j], neighbor[i]
            if neighbor not in tabu_list:
                neighbors.append(neighbor)
    if not neighbors:
        return tabu_list
    else:
        return neighbors

# calcula o custo de uma solução, que é a soma das distâncias entre as cidades
def calculate_cost(solution):
    cost = 0
    for i in range(len(solution)):
        cost += distance(solution[i-1], solution[i])
    return cost

# calcula a distância euclidiana entre duas cidades
def distance(city1, city2):
    return ((city1[0]-city2[0])**2 + (city1[1]-city2[1])**2)**0.5


if __name__ == '__main__':
    random.seed(42)
    cities = [(random.uniform(0, 10), random.uniform(0, 10)) for _ in range(10)]
    
    solution, cost = tsp_search(cities, max_iter=100, tabu_size=10)
    
    print('Melhor solucao encontrada:', solution)
    print('Custo da melhor solucao:', cost)
