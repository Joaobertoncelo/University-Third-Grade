package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
  /*
  ALUNO: Vítor Rodrigues Gôngora
  RA106769

  Problema da mochila binária

  Dada uma mochila com capacidade máxima de X kg e uma lista com Y itens com seus pesos e lucros,
  queremos escolher os itens de maneira a garantir o maior lucro possível.
  A mochila é binária, pois podemos apenas colocar o item de forma total ou não colocá-lo.

  Para o problema exemplo tem-se uma mochila com capacidade de 100 kg e os seguintes itens:
  Item 0 => Peso: 47kg - Lucro: 41
  Item 1 => Peso: 40kg - Lucro: 33
  Item 2 => Peso: 17kg - Lucro: 14
  Item 3 => Peso: 27kg - Lucro: 25
  Item 4 => Peso: 34kg - Lucro: 32
  Item 5 => Peso: 23kg - Lucro: 32
  Item 6 => Peso: 5kg - Lucro: 9
  Item 7 => Peso: 44kg - Lucro: 19

  Critério de aspiração: Se o movimento realizado para chegar em uma nova solução encontrada na
  vizinhança estiver na lista tabu, mas a solução foi melhor que a ótima ela é aceita e o seu prazo
  na lista tabu é renovado.

  O número de iterações, tamanho da lista tabu, e prazo da lista tabu podem ser alterados
  nas variáveis: maxIter, tamanhoListaTabu, prazoListaTabu.

  Os pesos e lucros dos itens, e capacidade máxima da mochila podem ser alterados nas variáveis:
  pesos, lucros e capacidadeMaxima.

  */

  static List<Integer> pesos = new ArrayList<>(Arrays.asList(47, 40, 17, 27, 34, 23, 5, 44));

  static List<Integer> lucros = new ArrayList<>(Arrays.asList(41, 33, 14, 25, 32, 32, 9, 19));

  static Integer capacidadeMaxima = 100;

  static Integer iterAtual = 0;

  // Limite máximo de iterações permitidas
  static Integer maxIter = 100;

  // Número máximo de itens na lista tabu
  static Integer tamanhoListaTabu = 3;

  // Prazo para sair da lista tabu
  static Integer prazoListaTabu = 5;

  // Solução inicial definida como não carregar nenhum item
  // Soluções dadas em Array [0, 0, 0, 0, 0, 0, 0] onde 0 significa que o item
  // não foi escolhido e 1 significa que o item foi escolhido
  static List<Integer> solucaoOtima = new ArrayList<>(Collections.nCopies(7, 0));

  static Integer lucroOtimo = 0;

  static List<Integer> solucaoAtual = new ArrayList<>(Collections.nCopies(7, 0));

  static Integer lucroAtual = 0;

  // Lista tabu onde key = casa movimentada (0 a 6), value = iterações restantes
  // a lista tabu pode ter 3 elementos somente
  static Map<Integer, Integer> listaTabu = new HashMap<>();

  public static void main(String[] args) {
    while (iterAtual < maxIter) {
      iterAtual++;
      atualizarListaTabu();
      encontrarSolucaoVizinhaOtima();

      // Se a solução atual for melhor que a solução ótima, atualiza a solução ótima
      if (lucroAtual > lucroOtimo) {
        lucroOtimo = lucroAtual;
        solucaoOtima = solucaoAtual;
      }

      System.out.println("ITERAÇÃO " + iterAtual);
      System.out.println("LISTA TABU " + listaTabu);
      System.out.println("SOLUÇÃO ÓTIMA " + solucaoOtima);
      System.out.println("LUCRO ÓTIMO " + lucroOtimo);
      System.out.println("SOLUÇÃO ATUAL " + solucaoAtual);
      System.out.println("LUCRO ATUAL " + lucroAtual);
      System.out.println("--------------------------------------");
    }
  }

  private static void encontrarSolucaoVizinhaOtima() {
    // Lista com as soluções, o valor da função objetivo e a casa onde o movimento foi realizado
    // EX: [1, 0, 0, 1, 1, 1, 1] e 57
    List<SolucaoVizinha> solucoes = new ArrayList<>();

    // Cria soluções vizinhas alterando a adição/remoção de um elemento da solução atual
    for (int i = 0; i < solucaoAtual.size(); i++) {
      SolucaoVizinha solucaoVizinha = new SolucaoVizinha();
      List<Integer> novaMochila = new ArrayList<>(solucaoAtual);

      // Troca 0 por 1 ou 1 por 0 na posição de i
      novaMochila.set(i, novaMochila.get(i) == 0 ? 1 : 0);

      // Calcula o lucro e peso total da mochila
      Integer lucroTotal = 0;
      Integer pesoTotal = 0;
      for (int j = 0; j < novaMochila.size(); j++) {
        // Se o item j está na mochila adiciona o lucro do item j
        if (novaMochila.get(j) == 1) {
          lucroTotal += lucros.get(j);
          pesoTotal += pesos.get(j);
        }
      }

      // Verifica se a solução é possível, isto é o peso é menor ou igual a capacidade máxima
      if (pesoTotal <= capacidadeMaxima) {
        solucaoVizinha.setSolucao(novaMochila);
        solucaoVizinha.setLucroTotal(lucroTotal);
        solucaoVizinha.setCasaMovimentada(i);
        // Verifica se está na lista tabu, se não estiver adiciona como solução
        if(!listaTabu.containsKey(i)){
          solucoes.add(solucaoVizinha);
        } else {
          // Critério de aspiração
          // Se o movimento estiver na lista tabu e a solução encontrada é melhor que a ótima
          // aceitar ela
          if(lucroTotal > lucroOtimo){
            solucoes.add(solucaoVizinha);
          }
        }
      }
    }

    if (!solucoes.isEmpty()) {
      List<Integer> melhorSolucaoVizinha = new ArrayList<>();
      Integer melhorLucroSolucaoVizinha = -999;
      Integer melhorSolucaoCasaMovimentada = -999;

      // Encontra a solução que trará maior lucro
      for (SolucaoVizinha solucao : solucoes) {
        if (solucao.getLucroTotal() > melhorLucroSolucaoVizinha) {
          melhorSolucaoVizinha = solucao.getSolucao();
          melhorLucroSolucaoVizinha = solucao.getLucroTotal();
          melhorSolucaoCasaMovimentada = solucao.getCasaMovimentada();
        }
      }

      // Adiciona o movimento na lista tabu
      adicionarItemListaTabu(melhorSolucaoCasaMovimentada);

      // Troca a solução atual pela agora encontrada
      solucaoAtual = melhorSolucaoVizinha;
      lucroAtual = melhorLucroSolucaoVizinha;
    }
  }

  private static void atualizarListaTabu() {
    if (!listaTabu.isEmpty()) {
      Map<Integer, Integer> listaTabuIterable = new HashMap<>(listaTabu);

      for (Map.Entry<Integer, Integer> set : listaTabuIterable.entrySet()) {
        if (set.getValue() <= 1) {
          // Se o número de iterações restante é 1 remove o item da lista
          listaTabu.remove(set.getKey(), set.getValue());
        } else {
          // Reduz o número de iterações restantes na lista tabu
          listaTabu.replace(set.getKey(), set.getValue(), set.getValue() - 1);
        }
      }
    }
  }

  private static void adicionarItemListaTabu(Integer casa) {
    // Mantem um número limitado de itens na lista tabu
    // Se o limite for atingido remove o item com menor prazo
    if (listaTabu.size() >= tamanhoListaTabu) {

      Integer chaveComMenorPrazo = 999;
      Integer menorPrazo = 999;

      for (Map.Entry<Integer, Integer> set : listaTabu.entrySet()) {
        if (set.getValue() < menorPrazo) {
          menorPrazo = set.getValue();
          chaveComMenorPrazo = set.getKey();
        }
      }
      listaTabu.remove(chaveComMenorPrazo, menorPrazo);
    }

    if(listaTabu.containsKey(casa)) {
      // Se o item já está na lista tabu e foi selecionado por aspiração
      // renova o prazo para o valor inicial
      listaTabu.replace(casa, listaTabu.get(casa), prazoListaTabu);
    } else {
      // Se o item não está na lista tabu o adiciona com prazo de 5 iterações
      listaTabu.put(casa, prazoListaTabu);
    }

  }
}
