package org.example;

import java.util.List;

public class SolucaoVizinha {
  private List<Integer> solucao;
  private Integer casaMovimentada;
  private Integer lucroTotal;
  private Integer pesoTotal;

  public SolucaoVizinha() {}

  public List<Integer> getSolucao() {
    return solucao;
  }

  public void setSolucao(List<Integer> solucao) {
    this.solucao = solucao;
  }

  public Integer getCasaMovimentada() {
    return casaMovimentada;
  }

  public void setCasaMovimentada(Integer casaMovimentada) {
    this.casaMovimentada = casaMovimentada;
  }

  public Integer getLucroTotal() {
    return lucroTotal;
  }

  public void setLucroTotal(Integer lucroTotal) {
    this.lucroTotal = lucroTotal;
  }

  public Integer getPesoTotal() {
    return pesoTotal;
  }

  public void setPesoTotal(Integer pesoTotal) {
    this.pesoTotal = pesoTotal;
  }
}
