# Classe para a lista tabu especializada para o problemas das n rainhas
class ListaTabu:
    def __init__(self, n, time):
        self.n = n

        # Inicializa uma Matriz de Atributos Tabu de uma solução
        # Representa os possíveis movimentos de trocas 
        # de rainhas em um tabuleiro n x n
        self.lista = [[0 for j in range(0,n)] for i in range(0,n)]

        # Número de iterações em que um atributo permanece tabu ativo
        self.time = time

    def __str__(self):
        return '\n'.join([' '.join(["%02d" % (self.lista[i][j]) for j in range(i,self.n)]) for i in range(0, self.n)])

    # Atualiza o prazu tabu de cada atributo na lista
    # Remove o estado tabu ativo do atributo se já se deu o seu tempo tabu
    def update(self):
        for i in range(0, self.n):
            for j in range(i, self.n):
                if self.lista[i][j] > 0:
                    self.lista[i][j] -= 1

                if self.lista[i][j] >= self.time:
                    self.lista[i][j] = 0

    # Adiciona um atributo a lista tabu
    def add(self, i, j):
        i,j = get_index(i, j)

        # lista[i][j] e lista[j][i] são considerados o mesmo movimento
        self.lista[i][j] = self.time

    # Verifica se um possível movimento está na lista tabu
    def check(self, i, j):
        i, j = get_index(i, j)
        return self.lista[i][j] > 0

# Função auxiliar para manter matriz lista
# uma matriz triangular 
def get_index(i, j):
    if j < i:
        return j, i
    return i, j
