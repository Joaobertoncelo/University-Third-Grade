# Alunos: Victor Hugo do Nascimento Bueno RA:112651,
# Ana Heloisa Bravin Mazur RA:118003,
# Natalia Mami Oyama RA:112652.

# Implementacao para o problema combinatorio das N-Rainhas

from tabuleiro import Tabuleiro
from lista_tabu import ListaTabu

def busca_tabu(n, tempo_tabu, max_iter, echo=False):
    t = Tabuleiro(n)
    tabu = ListaTabu(n, tempo_tabu)

    atual = t.calc_colisoes() # calcula número inicial de colisões
    best = atual # menor número de colisões até agora
 
    iter = 0
    
    if echo:
        print("\nsolucao inicial:\n " + str(t), end="\n")
        print("número de colisões: %d" % atual)

    # o loop vai até iter_max iterações ou até resolver o problema
    # (quando o número de colisões é 0)
    while iter < max_iter and atual != 0:
        best_eval = n
        best_swap = None

        for i in range(0, n - 1):
            for j in range(i+1, n):
                delta = t.eval_swap(i, j) # avalia troca das rainhas i e j
           
                # descobre melhor movimento na vizinhança
                if (not tabu.check(i, j) and delta < best_eval) or (atual + delta < best):
                    best_swap = i, j
                    best_eval = delta

                    # atualiza menor número de colisões
                    if atual + delta < best:
                        best = atual + delta

        if best_swap: # se existe um movimento
            # atualiza número de colisões
            atual += best_eval

            a, b = best_swap
            t.swap(a, b) # troca elementos

        tabu.add(a, b) # adiciona movimento a lista tabu
        tabu.update() # atualiza lista tabu

        if echo:
            print("\niteração: %d" % iter) 
            print('trocando rainhas %d e %d:' % (a, b))    
            print(t,end="\n")

            print("atual número de colisões: %d" % atual)
            print("menor número de colisões: %d" % best)

        iter += 1
  
    if echo:
        print('\nsolução final:\n' + str(t))
        print('iterações totais: %d' % iter)
        print('número de colisões: %d' % atual)

    return (t, iter)

if __name__ == '__main__':
    n_rainhas = int(input('digite o número de rainhas: '))
    tempo_tabu = int(input('digite o tempo tabu: '))
    iter = int(input('digite o número máximo de iterações: '))

    busca_tabu(n_rainhas, tempo_tabu, iter, echo=True)


