import random 

class Tabuleiro:
    def __init__(self, n):
        self.n = n 

        # Quantidade de diagonais em um tabuleiro
        self.diag = 2 * n - 1

        # Permutação de Rainhas
        # Cada rainha i é posicionada na coluna e na linha p[i] 
        self.p = random.sample(range(0, n), n)

        # Quantidade de Rainhas em cada diagonal
        self.update_diagonals()

    # Transforma o tabuleiro em uma representação em string
    def __str__(self):
        return '\n'.join([' '.join(['x' if self.p[i] == j else '.' for j in range(0, self.n)]) for i in range(0, self.n)])
    
    # Atualiza a quantidade de rainhas em cada diagonal
    def update_diagonals(self):
        self.negative = [0 for i in range(0, self.diag)]
        self.positive = [0 for i in range(0, self.diag)]

        for i in range(0, self.n):
            self.inc_diagonais(i)

    # Retorna o índice das diagonais afetadas 
    # por uma rainha na linha i
    def get_diagonais(self, i):
        j = self.p[i]

        # a soma da linha e coluna é constante
        # para cada diagonal negativa
        d1 = (i + j)

        # a diferença entre a linha e a coluna
        # é constante para cada diagonal positiva 
        d2 = (self.n - 1) + (i - j)

        return d1, d2

    # Atualiza as diagonais ao retirar uma
    # rainha da linha i
    def dec_diagonais(self, i):
        d1, d2 = self.get_diagonais(i)
        
        self.negative[d1] -= 1
        self.positive[d2] -= 1

    # Atualiza as diagonais ao posicionar
    # uma rainha na linha i
    def inc_diagonais(self, i):
        d1, d2 = self.get_diagonais(i)

        self.negative[d1] += 1
        self.positive[d2] += 1

    # Calcula o número total de colisões no tabuleiro
    def calc_colisoes(self):
        c = 0

        for i in range(0, self.n):
            d1, d2 = self.get_diagonais(i)
            c += self.negative[d1] - 1
            c += self.positive[d2] - 1

        return c

    # Troca as colunas das rainhas a e b
    # Movimento para obter uma nova solução na vizinhança
    def swap(self, a, b):
        # Atualiza diagonais que não seram mais afetadas
        self.dec_diagonais(a)
        self.dec_diagonais(b)

        self.p[a], self.p[b] = self.p[b], self.p[a] 

        # Atualiza as diagonais afetadas na nova posição
        self.inc_diagonais(a)
        self.inc_diagonais(b)

    # Avalia a troca das colunas das rainhas a e b
    # retorna a diferença do número de colisões
    def eval_swap(self, a, b):
      
        c1 = self.calc_colisoes()
        self.swap(a, b)
        c2 = self.calc_colisoes()

        d = c2 - c1 # calcula a variação no número de colisões 
        self.swap(a, b) # retorna a configuração inicial

        return d
   
