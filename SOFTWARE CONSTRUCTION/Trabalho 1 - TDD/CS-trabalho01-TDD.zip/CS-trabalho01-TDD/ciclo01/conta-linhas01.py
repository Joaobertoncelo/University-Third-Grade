# Nome: 
# RA: 

# 2o passo (green): escreva o código para fazer o caso de teste passar
def conta_linhas():
	pass

# 1o passo (red): escreva um caso de teste 	
def test_01():
	# formato do caso de teste automatizado
	# assert conta_linhas(entrada) == saida_esperada
